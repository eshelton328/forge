// Rooster Beacon (ESP32-C3) + LD2410 (UART) + ESP-NOW
//
// Behavior:
// - Receives TEST_START/TEST_STOP from Cube over ESP-NOW.
// - Replies immediately with ROGER.
// - Sends STATUS periodically while test is running.
// - Yellow LED = "latched filtered presence": turns OFF only if filtered presence has been lost > 5s (hard-coded).
// - Green LED  = SUCCESS: turns ON after required held time (from Cube), based on filtered presence.
// - Held time pauses during brief losses; resets if loss lasts > 5s (hard-coded).
//
// IMPORTANT:
// - ESPNOW_CHANNEL must match Cube.
// - We do NOT expose loss_grace_ms or dist_stale_ms to the user (hard-coded).

#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "esp_idf_version.h"

#include <MyLD2410.h>

// ====================== ESPNOW CONFIG ======================
static const uint8_t ESPNOW_CHANNEL = 1; // MUST MATCH CUBE

static const uint32_t MSG_MAGIC = 0x52535431; // 'RST1'

enum MsgType : uint8_t {
  // Cube -> Beacon
  MSG_TEST_START = 1,
  MSG_TEST_STOP  = 2,
  MSG_PING       = 3,

  // Beacon -> Cube
  MSG_ROGER      = 101,
  MSG_STATUS     = 102
};

#pragma pack(push, 1)
struct CubeToBeacon {
  uint32_t magic;
  uint8_t  version;
  uint8_t  type;
  uint16_t seq;

  // Only user-facing contract fields:
  uint8_t  maxDistHalfFt;   // 0.5ft units
  uint16_t hold15sUnits;    // 15s units
};

struct BeaconToCube {
  uint32_t magic;
  uint8_t  version;
  uint8_t  type;
  uint16_t seq;

  uint8_t  presence;   // 0/1 (we send "latched presence" = yellow LED state)
  uint8_t  success;    // 0/1 (green LED state)
  uint16_t held15s;    // how many 15s units accumulated (for display)
};
#pragma pack(pop)

static uint8_t  g_cubeMac[6] = {0};
static bool     g_haveCubeMac = false;
static uint16_t g_txSeq = 1;

#if ESP_IDF_VERSION_MAJOR >= 5
static void onEspNowSent(const wifi_tx_info_t* info, esp_now_send_status_t status) {
  (void)info; (void)status;
}
#else
static void onEspNowSent(const uint8_t* mac, esp_now_send_status_t status) {
  (void)mac; (void)status;
}
#endif

static void printMac(const uint8_t mac[6]) {
  Serial.printf("%02X:%02X:%02X:%02X:%02X:%02X",
                mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static void ensurePeer(const uint8_t mac[6]) {
  if (esp_now_is_peer_exist(mac)) return;

  esp_now_peer_info_t p{};
  memcpy(p.peer_addr, mac, 6);
  p.channel = ESPNOW_CHANNEL;
  p.encrypt = false;

  esp_err_t e = esp_now_add_peer(&p);
  Serial.print("ESP-NOW add peer ");
  printMac(mac);
  Serial.print(" => ");
  Serial.println((int)e);
}

static void wifiForceChannel(uint8_t ch) {
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  uint8_t primary = 0;
  wifi_second_chan_t second = WIFI_SECOND_CHAN_NONE;
  esp_wifi_get_channel(&primary, &second);
  Serial.printf("WiFi channel now = %u\n", primary);
}

static bool initEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true, true);
  delay(50);

  wifiForceChannel(ESPNOW_CHANNEL);

  Serial.print("Beacon STA MAC: ");
  uint8_t mac[6];
  WiFi.macAddress(mac);
  printMac(mac);
  Serial.println();

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    return false;
  }

  esp_now_register_send_cb(onEspNowSent);

  // recv cb registered below (needs forward decl)
  return true;
}

// ====================== LD2410 CONFIG ======================
// LED pins (per your wiring)
static const uint8_t PIN_LED_YELLOW = 4;
static const uint8_t PIN_LED_GREEN  = 3;

// UART pins (ESP32-C3)
static const int UART_RX = 20; // LD2410 TX -> here
static const int UART_TX = 21; // LD2410 RX -> here

// Hard-coded (NOT user-facing)
static const uint32_t LOSS_GRACE_MS = 5000;  // yellow off only after 5s loss; held reset after 5s loss
static const uint32_t DIST_STALE_MS = 750;   // when distance=0cm, allow last valid distance briefly
static const uint32_t MSG_SILENT_MS = 1500;  // if no radar DATA frames arrive, treat raw as "No"

// Debug/print
static const uint32_t PRINT_EVERY_MS = 250;

// Sensor tuning (same as your prior)
static const uint8_t NO_ONE_WINDOW_SEC = 1;
static const uint8_t MOVING_THRESHOLD     = 20;
static const uint8_t STATIONARY_THRESHOLD = 20;
static const uint8_t MAX_MOVING_GATE      = 8;
static const uint8_t MAX_STATIONARY_GATE  = 8;

HardwareSerial RadarSerial(1);
MyLD2410 radar(RadarSerial);

// ====================== TEST STATE ======================
static bool     testEnabled = false;

// From Cube (user settings only)
static float    maxDistanceFt = 5.0f;     // default if Cube never sends
static uint32_t requiredOnMs  = 15000;    // default 15s if Cube never sends

// Radar/raw state
static bool     rawPresent  = false;
static uint32_t lastDataMs  = 0;

// Distance tracking
static unsigned long lastValidDistCm = 0;
static uint32_t      lastValidDistMs = 0;

// Filtered + latched presence
static bool     filtPresent = false;
static bool     latchedPresence = false; // drives yellow LED + sent as "presence"
static uint32_t lastFiltYesMs = 0;       // last time filtPresent was true
static uint32_t lastFiltNoStartMs = 0;   // when filtPresent last went false

// Held accumulation
static uint32_t heldAccumMs    = 0;
static uint32_t lastHeldTickMs = 0;
static uint32_t lossStartMs    = 0;

// Success
static bool     success = false;

// Status tx
static uint32_t lastStatusTxMs = 0;
static const uint32_t STATUS_TX_EVERY_MS = 200;

// Print
static uint32_t lastPrintMs = 0;

// ====================== HELPERS ======================
static inline void ledYellow(bool on) { digitalWrite(PIN_LED_YELLOW, on ? HIGH : LOW); }
static inline void ledGreen(bool on)  { digitalWrite(PIN_LED_GREEN,  on ? HIGH : LOW); }

static float cmToFeet(unsigned long cm) { return (float)cm / 30.48f; }

static float halfFtToFt(uint8_t halfFt) { return (float)halfFt * 0.5f; }

static uint32_t time15sToMs(uint16_t units15s) { return (uint32_t)units15s * 15000UL; }

static void resetHeldAndSuccess() {
  heldAccumMs = 0;
  lastHeldTickMs = 0;
  lossStartMs = 0;
  success = false;
}

static void applySensorTuning() {
  radar.configMode();
  radar.requestParameters();

  radar.setNoOneWindow(NO_ONE_WINDOW_SEC);
  radar.setGateParameters(0xFF, MOVING_THRESHOLD, STATIONARY_THRESHOLD);
  radar.setMaxGate(MAX_MOVING_GATE, MAX_STATIONARY_GATE, NO_ONE_WINDOW_SEC);

  radar.configMode(false);
  radar.enhancedMode();
}

static bool computeFilteredPresence(bool raw, unsigned long distCm, uint32_t nowMs) {
  if (!raw) return false;

  unsigned long useCm = distCm;

  if (useCm == 0) {
    if (lastValidDistCm == 0) return false;
    if (nowMs - lastValidDistMs > DIST_STALE_MS) return false;
    useCm = lastValidDistCm;
  }

  const float distFt = cmToFeet(useCm);
  return (distFt <= maxDistanceFt);
}

static uint16_t heldTo15sUnits(uint32_t heldMs) {
  return (uint16_t)(heldMs / 15000UL);
}

// ====================== ESP-NOW SENDS ======================
static void sendRoger(uint16_t rxSeq) {
  if (!g_haveCubeMac) return;

  BeaconToCube msg{};
  msg.magic = MSG_MAGIC;
  msg.version = 1;
  msg.type = MSG_ROGER;
  msg.seq = rxSeq;

  ensurePeer(g_cubeMac);
  esp_err_t e = esp_now_send(g_cubeMac, (uint8_t*)&msg, sizeof(msg));
  Serial.print("Send ROGER => ");
  Serial.println((int)e);
}

static void sendStatus() {
  if (!testEnabled) return;
  if (!g_haveCubeMac) return;

  BeaconToCube msg{};
  msg.magic = MSG_MAGIC;
  msg.version = 1;
  msg.type = MSG_STATUS;
  msg.seq = g_txSeq++;

  msg.presence = latchedPresence ? 1 : 0;
  msg.success  = success ? 1 : 0;
  msg.held15s  = heldTo15sUnits(heldAccumMs);

  ensurePeer(g_cubeMac);
  esp_now_send(g_cubeMac, (uint8_t*)&msg, sizeof(msg));
}

// ====================== ESP-NOW RECV ======================
static void onEspNowRecv(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
  if (len < (int)sizeof(CubeToBeacon)) return;

  CubeToBeacon msg{};
  memcpy(&msg, data, sizeof(msg));

  if (msg.magic != MSG_MAGIC) return;
  if (msg.version != 1) return;

  memcpy(g_cubeMac, info->src_addr, 6);
  g_haveCubeMac = true;
  ensurePeer(g_cubeMac);

  if (msg.type == MSG_TEST_START) {
    maxDistanceFt = halfFtToFt(msg.maxDistHalfFt);
    requiredOnMs  = time15sToMs(msg.hold15sUnits);

    testEnabled = true;
    resetHeldAndSuccess();

    // Presence latch should reflect current state quickly
    latchedPresence = false;
    lastFiltYesMs = 0;
    lastFiltNoStartMs = millis();

    Serial.print("RX TEST_START from ");
    printMac(g_cubeMac);
    Serial.print(" | maxDist=");
    Serial.print(maxDistanceFt, 2);
    Serial.print("ft | required=");
    Serial.print(requiredOnMs / 1000);
    Serial.println("s");

    sendRoger(msg.seq);
  }
  else if (msg.type == MSG_TEST_STOP) {
    Serial.print("RX TEST_STOP from ");
    printMac(g_cubeMac);
    Serial.println();

    testEnabled = false;
    resetHeldAndSuccess();
    latchedPresence = false;
    ledYellow(false);
    ledGreen(false);

    sendRoger(msg.seq);
  }
  else if (msg.type == MSG_PING) {
    sendRoger(msg.seq);
  }
}

// ====================== SETUP / LOOP ======================
void setup() {
  pinMode(PIN_LED_YELLOW, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  ledYellow(false);
  ledGreen(false);

  Serial.begin(115200);
  delay(200);

  Serial.println("\n--- Rooster Beacon: ESP32-C3 + LD2410 + ESP-NOW ---");
  Serial.printf("ESPNOW_CHANNEL=%u\n", ESPNOW_CHANNEL);

  // Radar UART
  Serial.printf("UART: 256000 8N1 RX=%d TX=%d\n", UART_RX, UART_TX);
  RadarSerial.begin(256000, SERIAL_8N1, UART_RX, UART_TX);

  radar.begin();
  radar.enhancedMode();
  applySensorTuning();

  lastDataMs = millis();
  lastValidDistCm = 0;
  lastValidDistMs = 0;

  // ESP-NOW
  bool ok = initEspNow();
  Serial.println(ok ? "ESP-NOW init OK" : "ESP-NOW init FAIL");
  esp_now_register_recv_cb(onEspNowRecv);
}

void loop() {
  const uint32_t now = millis();

  // ----- Radar frames -----
  if (radar.check() == MyLD2410::DATA) {
    lastDataMs = now;
    rawPresent = radar.presenceDetected();
  }

  if (now - lastDataMs > MSG_SILENT_MS) rawPresent = false;

  unsigned long distCm = rawPresent ? radar.detectedDistance() : 0;

  if (rawPresent && distCm > 0) {
    lastValidDistCm = distCm;
    lastValidDistMs = now;
  }

  // ----- Filtered presence -----
  filtPresent = computeFilteredPresence(rawPresent, distCm, now);

  // ----- Presence latch (yellow behavior: off only after 5s of loss) -----
  if (filtPresent) {
    lastFiltYesMs = now;
    lastFiltNoStartMs = 0;
    latchedPresence = true;
  } else {
    if (lastFiltNoStartMs == 0) lastFiltNoStartMs = now;
    if (latchedPresence && (now - lastFiltNoStartMs) > LOSS_GRACE_MS) {
      latchedPresence = false;
    }
  }

  // ----- Held time + success (based on FILTERED presence, with same 5s grace) -----
  if (filtPresent) {
    if (lossStartMs != 0) {
      if (now - lossStartMs > LOSS_GRACE_MS) heldAccumMs = 0;
      lossStartMs = 0;
    }
    if (lastHeldTickMs == 0) lastHeldTickMs = now;
    heldAccumMs += (now - lastHeldTickMs);
    lastHeldTickMs = now;
  } else {
    lastHeldTickMs = 0;
    if (lossStartMs == 0) lossStartMs = now;
    if (now - lossStartMs > LOSS_GRACE_MS) heldAccumMs = 0;
  }

  if (!success && heldAccumMs >= requiredOnMs) success = true;

  // ----- LEDs -----
  ledYellow(latchedPresence);
  ledGreen(success);

  // ----- ESP-NOW status tx -----
  if (testEnabled && (now - lastStatusTxMs) >= STATUS_TX_EVERY_MS) {
    lastStatusTxMs = now;
    sendStatus();
  }

  // ----- Serial debug -----
  if (now - lastPrintMs >= PRINT_EVERY_MS) {
    lastPrintMs = now;

    Serial.print("Test: ");
    Serial.print(testEnabled ? "ON" : "OFF");

    Serial.print(" | Raw: ");
    Serial.print(rawPresent ? "Yes" : "No");

    Serial.print(" | Filt(<= ");
    Serial.print(maxDistanceFt, 1);
    Serial.print("ft): ");
    Serial.print(filtPresent ? "Yes" : "No");

    Serial.print(" | Yellow(latched): ");
    Serial.print(latchedPresence ? "Yes" : "No");

    Serial.print(" | Held: ");
    Serial.print(heldAccumMs / 1000);
    Serial.print("s/");
    Serial.print(requiredOnMs / 1000);
    Serial.print("s");

    Serial.print(" | SUCCESS: ");
    Serial.print(success ? "Yes" : "No");

    Serial.print(" | DistRaw: ");
    if (rawPresent && distCm > 0) {
      Serial.print(cmToFeet(distCm), 2);
      Serial.print(" ft");
    } else {
      Serial.print("--");
    }

    Serial.print(" | Status: ");
    Serial.println(radar.statusString());
  }

  delay(5);
}