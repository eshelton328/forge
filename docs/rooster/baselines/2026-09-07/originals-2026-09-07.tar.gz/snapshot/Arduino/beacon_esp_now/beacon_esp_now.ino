// beacon_rooster_ld2410c_session_event.ino (ESP32-C3 Beacon)
//
// Goals:
// - Always read LD2410C presence + distance while powered
// - Only transmit to Cube during an active session
// - TX pattern during session:
//     * ACK once on CONFIG
//     * PRESENCE on transitions 0<->1 (effective "cubePresent")
//     * optional HEARTBEAT resend (default 1500ms) for reliability (same state; NOT a “detected” event)
//     * SUCCESS once when held-time satisfied
//     * STOP: send final PRESENCE=0 once then go silent
//
// Key fixes vs your earlier session sketch:
// - Session timeout extended (so you don’t “stop mid-session” if Cube isn’t sending keepalives)
// - “Lost” is only sent after LOSS_GRACE_MS expires (unless STOP/timeout)
// - Yellow LED shows cubePresent (includes grace), so brief sensor flicker doesn’t look like a hard loss

#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_wifi_types.h>

#ifdef __has_include
  #if __has_include("esp_idf_version.h")
    #include "esp_idf_version.h"
  #endif
#endif

#ifndef ESP_IDF_VERSION_MAJOR
#define ESP_IDF_VERSION_MAJOR 5
#endif

#include <MyLD2410.h>

// ====================== ESP-NOW CONFIG ======================
static const uint8_t ESPNOW_CHANNEL = 9;
static const char    MAGIC_ROOS[4]  = {'R','O','O','S'};
static const uint8_t PROTO_VER      = 1;

// Message types
static const uint8_t MSG_CONFIG    = 1;
static const uint8_t MSG_ACK       = 2;
static const uint8_t MSG_PRESENCE  = 3;
static const uint8_t MSG_SUCCESS   = 4;
static const uint8_t MSG_STOP      = 5;

// ====================== LED PINS ======================
static const uint8_t PIN_LED_YELLOW = 4;
static const uint8_t PIN_LED_GREEN  = 3;

static inline void ledYellow(bool on) { digitalWrite(PIN_LED_YELLOW, on ? HIGH : LOW); }
static inline void ledGreen(bool on)  { digitalWrite(PIN_LED_GREEN,  on ? HIGH : LOW); }

// ====================== UART PINS (ESP32-C3) ======================
static const int UART_RX = 20; // ESP32 RX  (LD2410 TX -> here)
static const int UART_TX = 21; // ESP32 TX  (LD2410 RX -> here)

// ====================== BEHAVIOR KNOBS ======================
static const uint32_t LOSS_GRACE_MS   = 5'000;   // time allowed “lost” before we report present=0
static const uint32_t MSG_SILENT_MS   = 3'000;   // if no DATA frames arrive, treat raw as "No"
static const uint32_t PRINT_EVERY_MS  = 250;

static const bool     USE_LAST_DISTANCE_ON_MISSING = true;
static const uint32_t DIST_STALE_MS = 1'500;

// Optional reliability heartbeat (resend current cubePresent state)
static const bool     ENABLE_HEARTBEAT = true;
static const uint32_t HEARTBEAT_MS     = 1'500;

// Session timeout: large so it doesn’t end mid-session without keepalives.
// Cube will now send STOP when done.
static const uint32_t SESSION_TIMEOUT_MS  = 10UL * 60UL * 1000UL; // 10 minutes
static const uint32_t LATE_STOP_GRACE_MS  = 5'000;

// These are configured by Cube CONFIG (defaults used until first CONFIG arrives)
static float    maxDistanceFt = 5.0f;      // from distHalfFt / 2.0
static uint32_t requiredOnMs  = 60'000;    // from timeHalfMin * 30_000

// ====================== SENSOR TUNING (KEEP YOUR ORIGINAL) ======================
static const uint8_t NO_ONE_WINDOW_SEC      = 1;
static const uint8_t MOVING_THRESHOLD       = 20;
static const uint8_t STATIONARY_THRESHOLD   = 20;
static const uint8_t MAX_MOVING_GATE        = 8;
static const uint8_t MAX_STATIONARY_GATE    = 8;

// ====================== SERIAL + SENSOR ======================
HardwareSerial RadarSerial(1);
MyLD2410 radar(RadarSerial);

// ====================== ESP-NOW MESSAGE STRUCTS ======================
#pragma pack(push, 1)

struct BeaconCfgMsg {
  char     magic[4];        // "ROOS"
  uint8_t  version;         // 1
  uint8_t  msgType;         // 1=config
  uint8_t  distHalfFt;      // 1..16 (0.5..8.0 ft)
  uint8_t  timeHalfMin;     // 1..10 (0.5..5.0 min)
  uint32_t seq;             // incrementing
};

struct BeaconAckMsg {
  char     magic[4];        // "ROOS"
  uint8_t  version;         // 1
  uint8_t  msgType;         // 2=ack
  uint32_t seq;             // echoes config seq
  uint8_t  ok;              // 1=accepted, 0=bad
};

struct BeaconPresenceMsg {
  char     magic[4];        // "ROOS"
  uint8_t  version;         // 1
  uint8_t  msgType;         // 3=presence
  uint32_t seq;             // current config seq (or 0 if no session)
  uint8_t  present;         // 0/1 (effective presence for cube)
  uint16_t distCm;          // 0 if unknown
};

struct BeaconSuccessMsg {
  char     magic[4];        // "ROOS"
  uint8_t  version;         // 1
  uint8_t  msgType;         // 4=success
  uint32_t seq;             // current config seq
};

struct BeaconStopMsg {
  char     magic[4];        // "ROOS"
  uint8_t  version;         // 1
  uint8_t  msgType;         // 5=stop
  uint32_t seq;             // session/config seq to stop
};

#pragma pack(pop)

// ====================== STATE ======================
static bool     espNowOk = false;

// Learned Cube MAC
static bool     haveCubeMac = false;
static uint8_t  cubeMac[6]  = {0};

// Session state
static bool     sessionActive   = false;
static uint32_t sessionSeq      = 0;
static uint32_t lastHeardCfgMs  = 0;

// Late STOP handling
static uint32_t lastEndedSeq   = 0;
static uint32_t lastEndedAtMs  = 0;

// Presence state (always measured)
static bool     rawPresent  = false;
static bool     filtPresent = false;
static uint32_t lastDataMs  = 0;

// Held-time state (only used during session)
static uint32_t heldAccumMs    = 0;
static uint32_t lastHeldTickMs = 0;
static uint32_t lossStartMs    = 0;
static bool     hadFiltPresenceThisCfg = false;

static bool     successSentForThisCfg = false;

// Distance tracking
static unsigned long lastValidDistCm = 0;
static uint32_t      lastValidDistMs = 0;

// TX tracking (session-gated)
static uint32_t lastTxMs = 0;
static bool     lastSentPresent = false;
static bool     everSentAnyPresence = false;

static uint32_t lastPrintMs = 0;

// ====================== HELPERS ======================
static inline float cmToFeet(unsigned long cm) {
  return (float)cm / 30.48f;
}

static void applySensorTuning() {
  radar.configMode();
  radar.requestParameters();

  radar.setNoOneWindow(NO_ONE_WINDOW_SEC);
  radar.setGateParameters(0xFF, MOVING_THRESHOLD, STATIONARY_THRESHOLD);
  radar.setMaxGate(MAX_MOVING_GATE, MAX_STATIONARY_GATE, NO_ONE_WINDOW_SEC);

  radar.configMode(false);
  radar.enhancedMode();
}

static void forceChannel(uint8_t ch) {
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(ch, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);
}

static bool macEquals(const uint8_t* a, const uint8_t* b) {
  for (int i = 0; i < 6; i++) if (a[i] != b[i]) return false;
  return true;
}

static void printMac(const char* label, const uint8_t* mac) {
  Serial.printf("%s%02X:%02X:%02X:%02X:%02X:%02X\n",
                label, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

static bool ensurePeer(const uint8_t mac[6]) {
  if (esp_now_is_peer_exist(mac)) return true;

  esp_now_peer_info_t peer{};
  memcpy(peer.peer_addr, mac, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;

  esp_err_t e = esp_now_add_peer(&peer);
  Serial.printf("esp_now_add_peer => %d\n", (int)e);
  return (e == ESP_OK);
}

static void learnCubeMac(const uint8_t* src) {
  if (!src) return;
  if (!haveCubeMac || !macEquals(cubeMac, src)) {
    memcpy(cubeMac, src, 6);
    haveCubeMac = true;
    printMac("Learned Cube MAC = ", cubeMac);
    if (espNowOk) ensurePeer(cubeMac);
  }
}

static inline uint32_t halfMinToMs(uint8_t halfMin) {
  return (uint32_t)halfMin * 30000u;
}

static void resetHeld() {
  heldAccumMs = 0;
  lossStartMs = 0;
  lastHeldTickMs = 0;
}

static void resetConfigState() {
  resetHeld();
  hadFiltPresenceThisCfg = false;
  successSentForThisCfg  = false;
  lastTxMs = 0;
  everSentAnyPresence = false;
  lastSentPresent = false;
}

static void sendAck(uint32_t seq, uint8_t ok) {
  if (!espNowOk || !haveCubeMac) return;
  if (!ensurePeer(cubeMac)) return;

  BeaconAckMsg a{};
  memcpy(a.magic, MAGIC_ROOS, 4);
  a.version = PROTO_VER;
  a.msgType = MSG_ACK;
  a.seq = seq;
  a.ok  = ok;

  esp_err_t e = esp_now_send(cubeMac, (uint8_t*)&a, sizeof(a));
  Serial.printf("TX ACK seq=%u ok=%u err=%d\n", (unsigned)seq, (unsigned)ok, (int)e);
}

static void sendPresenceWithSeq(uint32_t seq, bool present, uint16_t distCm) {
  if (!espNowOk || !haveCubeMac) return;
  if (!ensurePeer(cubeMac)) return;

  BeaconPresenceMsg p{};
  memcpy(p.magic, MAGIC_ROOS, 4);
  p.version = PROTO_VER;
  p.msgType = MSG_PRESENCE;
  p.seq     = seq;
  p.present = present ? 1 : 0;
  p.distCm  = distCm;

  esp_err_t e = esp_now_send(cubeMac, (uint8_t*)&p, sizeof(p));
  Serial.printf("TX PRESENCE present=%u seq=%u distCm=%u err=%d\n",
                (unsigned)p.present, (unsigned)p.seq, (unsigned)p.distCm, (int)e);
}

static void sendPresence(bool present, uint16_t distCm) {
  sendPresenceWithSeq(sessionActive ? sessionSeq : 0, present, distCm);
}

static void sendSuccessOnce() {
  if (!espNowOk || !haveCubeMac) return;
  if (!sessionActive || sessionSeq == 0) return;
  if (successSentForThisCfg) return;
  if (!ensurePeer(cubeMac)) return;

  BeaconSuccessMsg s{};
  memcpy(s.magic, MAGIC_ROOS, 4);
  s.version = PROTO_VER;
  s.msgType = MSG_SUCCESS;
  s.seq     = sessionSeq;

  esp_err_t e = esp_now_send(cubeMac, (uint8_t*)&s, sizeof(s));
  Serial.printf("TX SUCCESS seq=%u err=%d\n", (unsigned)s.seq, (int)e);

  successSentForThisCfg = true;
}

static void stopSessionInternal(const char* why, bool sendFinalLost) {
  if (!sessionActive) return;

  Serial.printf("SESSION STOP (%s) seq=%u\n", why, (unsigned)sessionSeq);

  if (sendFinalLost) {
    sendPresenceWithSeq(sessionSeq, false, 0);
  }

  lastEndedSeq  = sessionSeq;
  lastEndedAtMs = millis();

  sessionActive  = false;
  sessionSeq     = 0;
  lastHeardCfgMs = 0;

  resetConfigState();
  ledYellow(false);
  ledGreen(false);
}

static unsigned long computeUsedDistanceCm(bool raw,
                                          unsigned long distCm,
                                          uint32_t nowMs) {
  if (!raw) return 0;
  if (distCm > 0) return distCm;

  if (USE_LAST_DISTANCE_ON_MISSING &&
      lastValidDistCm > 0 &&
      (uint32_t)(nowMs - lastValidDistMs) <= DIST_STALE_MS) {
    return lastValidDistCm;
  }

  return 0;
}

static bool computeFilteredPresence(bool raw, unsigned long usedCm) {
  if (!raw) return false;
  if (usedCm == 0) return false;
  return (cmToFeet(usedCm) <= maxDistanceFt);
}

// ====================== ESPNOW CALLBACKS ======================
#if ESP_IDF_VERSION_MAJOR >= 5
static void onEspNowSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  (void)info;
  Serial.printf("ESP-NOW send => %s\n", status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
}

static void onEspNowRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  if (!info || !info->src_addr || !data || len <= 0) return;
  const uint8_t* src = info->src_addr;
#else
static void onEspNowSent(const uint8_t *mac, esp_now_send_status_t status) {
  (void)mac;
  Serial.printf("ESP-NOW send => %s\n", status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
}

static void onEspNowRecv(const uint8_t *src, const uint8_t *data, int len) {
  if (!src || !data || len <= 0) return;
#endif

  if (len < 6) return;
  if (memcmp(data, MAGIC_ROOS, 4) != 0) return;
  if (data[4] != PROTO_VER) return;

  const uint8_t type = data[5];
  learnCubeMac(src);

  if (type == MSG_CONFIG) {
    if (len != (int)sizeof(BeaconCfgMsg)) return;

    BeaconCfgMsg cfg{};
    memcpy(&cfg, data, sizeof(cfg));

    bool ok = true;
    if (cfg.distHalfFt < 1 || cfg.distHalfFt > 16) ok = false;
    if (cfg.timeHalfMin < 1 || cfg.timeHalfMin > 10) ok = false;
    if (cfg.seq == 0) ok = false;

    Serial.printf("RX CONFIG seq=%u distHalfFt=%u timeHalfMin=%u ok=%u\n",
      (unsigned)cfg.seq, (unsigned)cfg.distHalfFt, (unsigned)cfg.timeHalfMin, ok ? 1u : 0u);

    sendAck(cfg.seq, ok ? 1 : 0);
    if (!ok) return;

    maxDistanceFt = (float)cfg.distHalfFt / 2.0f;
    requiredOnMs  = halfMinToMs(cfg.timeHalfMin);

    const bool newSeq = (!sessionActive) || (cfg.seq != sessionSeq);

    lastHeardCfgMs = millis();

    if (newSeq) {
      sessionActive = true;
      sessionSeq    = cfg.seq;
      resetConfigState();

      Serial.printf("SESSION START seq=%u maxDistanceFt=%.2f requiredOnMs=%lu\n",
                    (unsigned)sessionSeq, maxDistanceFt, (unsigned long)requiredOnMs);

      // Baseline: tell Cube "not present" once for the new seq.
      sendPresenceWithSeq(sessionSeq, false, 0);
      everSentAnyPresence = true;
      lastSentPresent = false;
      lastTxMs = millis();
    } else {
      // Keepalive (if Cube ever sends it): do NOT reset held.
    }
    return;
  }

  if (type == MSG_STOP) {
    if (len != (int)sizeof(BeaconStopMsg)) return;

    BeaconStopMsg st{};
    memcpy(&st, data, sizeof(st));

    Serial.printf("RX STOP seq=%u (active=%u current=%u)\n",
      (unsigned)st.seq, sessionActive ? 1u : 0u, (unsigned)sessionSeq);

    if (sessionActive && st.seq == sessionSeq) {
      stopSessionInternal("STOP msg", true);
      return;
    }

    const uint32_t now = millis();
    if (!sessionActive &&
        st.seq == lastEndedSeq &&
        (uint32_t)(now - lastEndedAtMs) <= LATE_STOP_GRACE_MS) {
      Serial.printf("RX STOP (late; already ended) seq=%u\n", (unsigned)st.seq);
      return;
    }

    Serial.printf("RX STOP ignored: msg.seq=%u current=%u active=%u\n",
      (unsigned)st.seq, (unsigned)sessionSeq, sessionActive ? 1u : 0u);
    return;
  }
}

// ====================== ESPNOW SETUP ======================
static bool setupEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false, true);
  delay(200);

  esp_wifi_set_ps(WIFI_PS_NONE);

  esp_err_t s = esp_wifi_start();
  Serial.printf("esp_wifi_start => %d\n", (int)s);

  forceChannel(ESPNOW_CHANNEL);

  if (esp_now_init() != ESP_OK) return false;

  esp_now_register_recv_cb(onEspNowRecv);
  esp_now_register_send_cb(onEspNowSent);
  return true;
}

// ====================== SETUP ======================
void setup() {
  pinMode(PIN_LED_YELLOW, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  ledYellow(false);
  ledGreen(false);

  Serial.begin(115200);
  delay(300);

  Serial.println("\n--- BEACON: ESP32-C3 + LD2410C (UART) + ESP-NOW ---");
  Serial.printf("UART: 256000 8N1 RX=%d TX=%d\n", UART_RX, UART_TX);
  Serial.printf("ESP-NOW channel=%u\n", (unsigned)ESPNOW_CHANNEL);

  RadarSerial.begin(256000, SERIAL_8N1, UART_RX, UART_TX);
  radar.begin();
  radar.enhancedMode();
  applySensorTuning();

  lastDataMs = millis();
  resetConfigState();

  Serial.printf("Defaults: maxDistanceFt=%.2f requiredOnMs=%lu\n",
                maxDistanceFt, (unsigned long)requiredOnMs);

  espNowOk = setupEspNow();
  Serial.println(espNowOk ? "ESP-NOW OK (RX ready)" : "ESP-NOW FAIL");

  Serial.print("Beacon WiFi.macAddress() = ");
  Serial.println(WiFi.macAddress());

  Serial.println("Beacon ready. Waiting for Cube CONFIG to start a session.");
}

// ====================== LOOP ======================
void loop() {
  const uint32_t now = millis();

  // ---------- Read/parse radar frames (always) ----------
  if (radar.check() == MyLD2410::DATA) {
    lastDataMs = now;
    rawPresent = radar.presenceDetected();
  }

  const uint32_t silentAge = now - lastDataMs;

  if (silentAge > MSG_SILENT_MS) {
    rawPresent = false;
  }

  // ---------- Distance ----------
  unsigned long distRawCm = rawPresent ? radar.detectedDistance() : 0;

  if (rawPresent && distRawCm > 0) {
    lastValidDistCm = distRawCm;
    lastValidDistMs = now;
  }

  const unsigned long distUsedCm = computeUsedDistanceCm(rawPresent, distRawCm, now);

  // ---------- Filtered presence ----------
  filtPresent = computeFilteredPresence(rawPresent, distUsedCm);
  if (filtPresent) hadFiltPresenceThisCfg = true;

  // ---------- Session timeout ----------
  if (sessionActive && lastHeardCfgMs != 0 &&
      (uint32_t)(now - lastHeardCfgMs) > SESSION_TIMEOUT_MS) {
    stopSessionInternal("timeout", true);
  }

  // ---------- During active session: held-time + TX ----------
  if (sessionActive) {
    // Held accumulates only while filtered present
    if (filtPresent) {
      if (lossStartMs != 0) lossStartMs = 0;

      if (lastHeldTickMs == 0) lastHeldTickMs = now;
      heldAccumMs += (now - lastHeldTickMs);
      lastHeldTickMs = now;
    } else {
      lastHeldTickMs = 0;
      if (lossStartMs == 0) lossStartMs = now;

      if (hadFiltPresenceThisCfg && (uint32_t)(now - lossStartMs) > LOSS_GRACE_MS) {
        heldAccumMs = 0;
      }
    }

    const bool greenNow = (heldAccumMs >= requiredOnMs);

    // Grace window: keep reporting present to Cube for LOSS_GRACE_MS
    const bool inGrace =
      (!filtPresent) &&
      hadFiltPresenceThisCfg &&
      (lossStartMs != 0) &&
      ((uint32_t)(now - lossStartMs) <= LOSS_GRACE_MS);

    const bool cubePresent = filtPresent || inGrace;

    // LEDs: show what the Cube is effectively seeing
    ledYellow(cubePresent);
    ledGreen(greenNow);

    // TX: transitions + optional heartbeat
    const bool stateChanged = (!everSentAnyPresence) || (cubePresent != lastSentPresent);
    const bool heartbeatDue = ENABLE_HEARTBEAT && everSentAnyPresence && ((uint32_t)(now - lastTxMs) >= HEARTBEAT_MS);

    if (haveCubeMac && (stateChanged || heartbeatDue)) {
      uint16_t d = 0;
      if (cubePresent && distUsedCm > 0) {
        d = (distUsedCm > 65535UL) ? 65535 : (uint16_t)distUsedCm;
      }
      sendPresence(cubePresent, d);
      lastTxMs = now;
      lastSentPresent = cubePresent;
      everSentAnyPresence = true;
    }

    if (greenNow) sendSuccessOnce();
  } else {
    // idle
    ledYellow(false);
    ledGreen(false);
    resetConfigState();
  }

  // ---------- Logs ----------
  if (now - lastPrintMs >= PRINT_EVERY_MS) {
    lastPrintMs = now;

    const float usedFt = (distUsedCm > 0) ? cmToFeet(distUsedCm) : 0.0f;
    const float rawFt  = (distRawCm  > 0) ? cmToFeet(distRawCm)  : 0.0f;

    Serial.printf(
      "TEL active=%u seq=%u raw=%u filt=%u held=%lu/%lu ms distRawFt=%s%.2f distUsedFt=%s%.2f maxFt=%.2f silentAge=%lu ms status=%s\n",
      sessionActive ? 1u : 0u,
      (unsigned)sessionSeq,
      rawPresent ? 1u : 0u,
      filtPresent ? 1u : 0u,
      (unsigned long)heldAccumMs,
      (unsigned long)requiredOnMs,
      (distRawCm  > 0) ? "" : "--", (distRawCm  > 0) ? rawFt  : 0.0f,
      (distUsedCm > 0) ? "" : "--", (distUsedCm > 0) ? usedFt : 0.0f,
      maxDistanceFt,
      (unsigned long)silentAge,
      radar.statusString()
    );
  }

  delay(5);
}