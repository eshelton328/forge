// ESP32-C3 + LD2410C (UART) using MyLD2410 library
// Option 2 (recommended): when raw presence is YES but distance is missing (0cm),
// use the last valid distance briefly (DIST_STALE_MS). If it goes stale, filtered presence = false.
//
// - Yellow LED = FILTERED presence
// - Green LED  = turns on after REQUIRED_ON_MS of accumulated HELD time (based on FILTERED presence)
// - Held time pauses during brief losses; resets if loss lasts > LOSS_GRACE_MS
// - Serial prints: Raw + Filtered + Held + DistUsed (feet) + DistRaw + Status

#include <Arduino.h>
#include <MyLD2410.h>

// ====================== LED PINS ======================
static const uint8_t PIN_LED_YELLOW = 4;
static const uint8_t PIN_LED_GREEN  = 3;

// ====================== UART PINS (ESP32-C3) ======================
static const int UART_RX = 20; // ESP32 RX  (LD2410 TX -> here)
static const int UART_TX = 21; // ESP32 TX  (LD2410 RX -> here)

// ====================== HELD-TIME RULES ======================
static const uint32_t REQUIRED_ON_MS  = 60'000; // green turns on after this much held time
static const uint32_t LOSS_GRACE_MS   = 5'000;  // allowed loss window before held time resets
static const uint32_t MSG_SILENT_MS   = 1'500;  // if no DATA frames arrive, treat raw as "No"
static const uint32_t PRINT_EVERY_MS  = 250;

// ====================== DISTANCE FILTER ======================
// MAX allowed distance. Beyond this => filtered presence = false.
static const float MAX_DISTANCE_FT = 5.0f;

// Option 2: use last valid distance briefly when distance is missing (0cm)
static const bool     USE_LAST_DISTANCE_ON_MISSING = true;  // <-- option 2 ON
static const uint32_t DIST_STALE_MS = 750;                  // tune 250–1500ms

// ====================== LATENCY / SENSOR TUNING ======================
static const uint8_t NO_ONE_WINDOW_SEC = 1; // try 1–3 seconds
static const uint8_t MOVING_THRESHOLD     = 20;
static const uint8_t STATIONARY_THRESHOLD = 20;
static const uint8_t MAX_MOVING_GATE     = 8;
static const uint8_t MAX_STATIONARY_GATE = 8;

// ====================== SERIAL + SENSOR ======================
HardwareSerial RadarSerial(1);
MyLD2410 radar(RadarSerial);

// ====================== STATE ======================
bool     rawPresent  = false;
bool     filtPresent = false;
uint32_t lastDataMs  = 0;

uint32_t heldAccumMs    = 0;
uint32_t lastHeldTickMs = 0;
uint32_t lossStartMs    = 0;

uint32_t lastPrintMs = 0;

// Last valid distance tracking
unsigned long lastValidDistCm = 0;
uint32_t      lastValidDistMs = 0;

// ====================== HELPERS ======================
static inline void ledYellow(bool on) { digitalWrite(PIN_LED_YELLOW, on ? HIGH : LOW); }
static inline void ledGreen(bool on)  { digitalWrite(PIN_LED_GREEN,  on ? HIGH : LOW); }

static float cmToFeet(unsigned long cm) {
  return (float)cm / 30.48f;
}

static void resetHeld() {
  heldAccumMs = 0;
  lossStartMs = 0;
  lastHeldTickMs = 0;
}

static void applySensorTuning() {
  radar.configMode();
  radar.requestParameters();

  radar.setNoOneWindow(NO_ONE_WINDOW_SEC);
  radar.setGateParameters(0xFF, MOVING_THRESHOLD, STATIONARY_THRESHOLD);
  radar.setMaxGate(MAX_MOVING_GATE, MAX_STATIONARY_GATE, NO_ONE_WINDOW_SEC);

  radar.configMode(false);
  radar.enhancedMode();
}

static bool computeFilteredPresence(bool raw,
                                   unsigned long distCm,
                                   uint32_t nowMs,
                                   unsigned long lastGoodCm,
                                   uint32_t lastGoodMs) {
  if (!raw) return false;

  unsigned long useCm = distCm;

  if (useCm == 0) {
    if (!USE_LAST_DISTANCE_ON_MISSING) return false;

    if (lastGoodCm == 0) return false;
    if (nowMs - lastGoodMs > DIST_STALE_MS) return false;

    useCm = lastGoodCm;
  }

  const float distFt = cmToFeet(useCm);
  return (distFt <= MAX_DISTANCE_FT);
}

static unsigned long computeUsedDistanceCm(bool raw,
                                          unsigned long distCm,
                                          uint32_t nowMs,
                                          unsigned long lastGoodCm,
                                          uint32_t lastGoodMs) {
  if (!raw) return 0;
  if (distCm > 0) return distCm;

  if (USE_LAST_DISTANCE_ON_MISSING &&
      lastGoodCm > 0 &&
      (nowMs - lastGoodMs) <= DIST_STALE_MS) {
    return lastGoodCm;
  }

  return 0;
}

void setup() {
  pinMode(PIN_LED_YELLOW, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);
  ledYellow(false);
  ledGreen(false);

  Serial.begin(115200);
  delay(200);

  Serial.println("\n--- ESP32-C3 + LD2410C (MyLD2410) ---");
  Serial.printf("UART: 256000 8N1 RX=%d TX=%d\n", UART_RX, UART_TX);

  RadarSerial.begin(256000, SERIAL_8N1, UART_RX, UART_TX);

  radar.begin();
  radar.enhancedMode();
  applySensorTuning();

  Serial.printf("Filter: MAX_DISTANCE_FT=%.2f | USE_LAST_DISTANCE_ON_MISSING=%s | DIST_STALE_MS=%lu\n",
                MAX_DISTANCE_FT,
                USE_LAST_DISTANCE_ON_MISSING ? "true" : "false",
                (unsigned long)DIST_STALE_MS);

  lastDataMs = millis();
  resetHeld();

  lastValidDistCm = 0;
  lastValidDistMs = 0;
}

void loop() {
  const uint32_t now = millis();

  // ---------- Read/parse frames ----------
  if (radar.check() == MyLD2410::DATA) {
    lastDataMs = now;
    rawPresent = radar.presenceDetected();
  }

  // If sensor goes silent, treat as lost
  if (now - lastDataMs > MSG_SILENT_MS) {
    rawPresent = false;
  }

  // ---------- Distance (raw) ----------
  unsigned long distCm = rawPresent ? radar.detectedDistance() : 0;

  // Track last valid distance
  if (rawPresent && distCm > 0) {
    lastValidDistCm = distCm;
    lastValidDistMs = now;
  }

  // ---------- Filtered presence ----------
  filtPresent = computeFilteredPresence(rawPresent, distCm, now, lastValidDistCm, lastValidDistMs);

  // For printing + debugging: what distance we actually used for filtering
  unsigned long usedCm = computeUsedDistanceCm(rawPresent, distCm, now, lastValidDistCm, lastValidDistMs);

  // ---------- Accumulate held time using FILTERED presence ----------
  if (filtPresent) {
    if (lossStartMs != 0) {
      if (now - lossStartMs > LOSS_GRACE_MS) {
        heldAccumMs = 0;
      }
      lossStartMs = 0;
    }

    if (lastHeldTickMs == 0) lastHeldTickMs = now;
    heldAccumMs += (now - lastHeldTickMs);
    lastHeldTickMs = now;
  } else {
    lastHeldTickMs = 0;

    if (lossStartMs == 0) lossStartMs = now;

    if (now - lossStartMs > LOSS_GRACE_MS) {
      heldAccumMs = 0;
    }
  }

  // ---------- LEDs ----------
  ledYellow(filtPresent);
  ledGreen(heldAccumMs >= REQUIRED_ON_MS);

  // ---------- Serial output ----------
  if (now - lastPrintMs >= PRINT_EVERY_MS) {
    lastPrintMs = now;

    Serial.print("Raw: ");
    Serial.print(rawPresent ? "Yes" : "No");

    Serial.print(" | Filt(<= ");
    Serial.print(MAX_DISTANCE_FT, 1);
    Serial.print("ft): ");
    Serial.print(filtPresent ? "Yes" : "No");

    Serial.print(" | Held: ");
    Serial.print(heldAccumMs / 1000);
    Serial.print("s");

    Serial.print(" | DistUsed: ");
    if (rawPresent && usedCm > 0) {
      Serial.print(cmToFeet(usedCm), 2);
      Serial.print(" ft");
    } else {
      Serial.print("--");
    }

    Serial.print(" | DistRaw: ");
    if (rawPresent && distCm > 0) {
      Serial.print(cmToFeet(distCm), 2);
      Serial.print(" ft");
    } else {
      Serial.print("--");
    }

    Serial.print(" | Status: ");
    Serial.println(radar.statusString());
  }

  delay(5);
}