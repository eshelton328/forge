// ESP32-S3 + MAX98357A + TPS61023: Loud + clear alarm tone sequence (sine wave, adjustable amplitude)
//
// Uses GPIO to control:
//  - TPS61023 EN (boost enable)
//  - MAX98357A SD (shutdown) pin
//
// Hardware recommendation:
//  - 10k pulldown on BOOST_EN (you verified 10k works on your module)
//  - 100k pulldown on AMP_SD (so amp defaults OFF during reset/boot/deep sleep)

#include <Arduino.h>
#include "driver/i2s.h"
#include <math.h>

#ifndef TWO_PI
#define TWO_PI 6.28318530717958647692f
#endif

// ----- I2S pins (match your cube wiring) -----
#define GPIO_I2S_BCLK   15
#define GPIO_I2S_LRCLK  16
#define GPIO_I2S_DATA   17

// ----- Power control pins -----
// TPS61023 EN pin (GPIO wired to EN). Use -1 if not wired.
#define PIN_BOOST_EN    18

// MAX98357A SD pin (GPIO wired to SD). Use -1 if not wired.
#define PIN_AMP_SD      21

// If your TPS61023 EN is active-low on your module (rare), set this to 0.
#define BOOST_EN_ACTIVE_HIGH 1

// For most MAX98357A breakouts: SD high = enabled, low = shutdown.
#define AMP_SD_ACTIVE_HIGH   1

static const i2s_port_t I2S_PORT = I2S_NUM_0;
static const int SAMPLE_RATE = 44100;

// Peak amplitude for sine (0..32767). Start lower if you hear distortion.
static const int16_t MAX_AMPL = 20000;

// ----- Alarm sequence (no gaps) -----
struct Note { float freq; float duration; };

static const Note melody[] = {
  {  880.0f, 0.25f },
  { 1047.0f, 0.25f },
  { 1319.0f, 0.25f },
  { 1047.0f, 0.25f },
  {  880.0f, 0.25f },
  { 1047.0f, 0.25f },
  { 1319.0f, 0.25f },
  { 1047.0f, 0.25f },
  {  880.0f, 0.25f },
  { 1047.0f, 0.25f },
  { 1319.0f, 0.25f },
  { 1047.0f, 0.25f },
  {  880.0f, 0.25f },
  { 1047.0f, 0.25f },
  {  880.0f, 0.25f },
  { 1047.0f, 0.25f },
};

static const int NUM_NOTES = sizeof(melody) / sizeof(melody[0]);

static float  melodyTotalSec = 0.0f;
static double melodyTimeSec  = 0.0;
static float  oscPhase       = 0.0f;

static float computeTotal() {
  float t = 0.0f;
  for (int i = 0; i < NUM_NOTES; i++) t += melody[i].duration;
  return t;
}

static float currentFreq() {
  float t = fmodf((float)melodyTimeSec, melodyTotalSec);
  float cursor = 0.0f;

  for (int i = 0; i < NUM_NOTES; i++) {
    float d = melody[i].duration;
    if (t < cursor + d) return melody[i].freq;
    cursor += d;
  }
  return melody[NUM_NOTES - 1].freq;
}

static inline void setBoostEnabled(bool on) {
  if (PIN_BOOST_EN < 0) return;
  if (BOOST_EN_ACTIVE_HIGH) digitalWrite(PIN_BOOST_EN, on ? HIGH : LOW);
  else                      digitalWrite(PIN_BOOST_EN, on ? LOW  : HIGH);
}

static inline void setAmpEnabled(bool on) {
  if (PIN_AMP_SD < 0) return;
  if (AMP_SD_ACTIVE_HIGH) digitalWrite(PIN_AMP_SD, on ? HIGH : LOW);
  else                    digitalWrite(PIN_AMP_SD, on ? LOW  : HIGH);
}

static bool installI2S() {
  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };

  if (i2s_driver_install(I2S_PORT, &cfg, 0, NULL) != ESP_OK) return false;

  i2s_pin_config_t pins = {
    .bck_io_num = GPIO_I2S_BCLK,
    .ws_io_num = GPIO_I2S_LRCLK,
    .data_out_num = GPIO_I2S_DATA,
    .data_in_num = I2S_PIN_NO_CHANGE
  };

  if (i2s_set_pin(I2S_PORT, &pins) != ESP_OK) return false;

  if (i2s_set_clk(I2S_PORT, SAMPLE_RATE, I2S_BITS_PER_SAMPLE_16BIT, I2S_CHANNEL_STEREO) != ESP_OK) {
    return false;
  }

  i2s_zero_dma_buffer(I2S_PORT);
  i2s_start(I2S_PORT);
  return true;
}

void setup() {
  Serial.begin(115200);
  delay(200);

  // Configure control pins early and default them OFF.
  if (PIN_BOOST_EN >= 0) {
    pinMode(PIN_BOOST_EN, OUTPUT);
    setBoostEnabled(false);
  }
  if (PIN_AMP_SD >= 0) {
    pinMode(PIN_AMP_SD, OUTPUT);
    setAmpEnabled(false);
  }

  melodyTotalSec = computeTotal();

  // Power-up sequence:
  // 1) Enable boost, wait for 5V rail to stabilize
  setBoostEnabled(true);
  delay(15); // 10–30ms is typically plenty; tune as needed for your module

  // 2) Enable amp (exits shutdown) after 5V is present
  setAmpEnabled(true);
  delay(5);

  // 3) Start I2S
  if (!installI2S()) {
    Serial.println("I2S install failed");
    setAmpEnabled(false);
    setBoostEnabled(false);
    while (true) delay(1000);
  }

  Serial.println("Alarm running (sine, MAX_AMPL adjustable, boost EN + amp SD controlled)");
}

void loop() {
  static const int FRAMES = 256;
  int16_t samples[FRAMES * 2];

  for (int i = 0; i < FRAMES; i++) {
    float freq = currentFreq();

    float phaseInc = (float)(TWO_PI * freq / (float)SAMPLE_RATE);
    oscPhase += phaseInc;
    if (oscPhase >= TWO_PI) oscPhase -= TWO_PI;

    float s = sinf(oscPhase);
    int32_t v = (int32_t)(s * (float)MAX_AMPL);

    if (v > 32767) v = 32767;
    if (v < -32768) v = -32768;

    int16_t out = (int16_t)v;
    samples[2 * i + 0] = out;
    samples[2 * i + 1] = out;

    melodyTimeSec += 1.0 / (double)SAMPLE_RATE;
  }

  size_t bytesWritten = 0;
  i2s_write(I2S_PORT, (const char*)samples, sizeof(samples), &bytesWritten, portMAX_DELAY);
}