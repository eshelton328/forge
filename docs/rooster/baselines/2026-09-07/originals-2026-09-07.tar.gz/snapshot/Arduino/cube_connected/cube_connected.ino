// cube_rooster_espnow_testmode.ino  (ESP32-S3 Cube)
//
// OLED UI + I2S alarm + ESP-NOW test mode
//
// Test mode behavior (SCREEN_TEST):
// - "Start": send CONFIG to beacon + start sound immediately
// - Wait for ACK (timeout => Error reaching beacon, stop sound, return to Start)
// - Presence=1: silence sound immediately
// - Presence=0: resume sound only after sustained loss (PRESENCE_LOSS_HOLD_MS)
// - SUCCESS: "Success", stop sound, return to Start
// - Bottom status message auto-clears after 5 seconds
// - No extra "(TEST)" label is drawn

#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include "driver/i2s.h"
#include <math.h>

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include "esp_idf_version.h"
#include <esp_wifi_types.h>

#include "esp_sleep.h"
#include "driver/rtc_io.h"

#ifndef TWO_PI
#define TWO_PI 6.28318530717958647692f
#endif

// ====================== PIN SELECTION FOR ESP32-S3 ======================
#define GPIO_I2S_BCLK    15
#define GPIO_I2S_LRCLK   16
#define GPIO_I2S_DATA    17

#define PIN_VOL_UP       5
#define PIN_VOL_DOWN     6
#define PIN_MODE         4

#define OLED_SDA_PIN     8
#define OLED_SCL_PIN     9

#define I2S_PORT         I2S_NUM_0

// ====================== ESP-NOW CONFIG ======================
static const uint8_t ESPNOW_CHANNEL = 9; // must match beacon
static uint8_t BEACON_MAC[6] = { 0x40, 0x4C, 0xCA, 0x3C, 0x51, 0xA4 }; // Beacon STA MAC

static const char MAGIC_ROOS[4] = { 'R','O','O','S' };
static const uint8_t PROTO_VER  = 1;

enum MsgType : uint8_t {
  MSG_CONFIG   = 1,
  MSG_ACK      = 2,
  MSG_PRESENCE = 3,
  MSG_SUCCESS  = 4
};

// ====================== TEST SESSION TYPES (DEFINE BEFORE USE) ======================
enum TestStatus : uint8_t {
  TEST_STATUS_NONE = 0,
  TEST_STATUS_ERROR,
  TEST_STATUS_PRESENCE_DETECTED,
  TEST_STATUS_PRESENCE_LOST,
  TEST_STATUS_SUCCESS
};

static inline const char* testStatusToText(TestStatus s) {
  switch (s) {
    case TEST_STATUS_ERROR:             return "Error reaching beacon";
    case TEST_STATUS_PRESENCE_DETECTED: return "Human Presence Detected";
    case TEST_STATUS_PRESENCE_LOST:     return "Human Presence Lost";
    case TEST_STATUS_SUCCESS:           return "Success";
    default:                            return "";
  }
}

#pragma pack(push, 1)
struct BeaconCfgMsg {
  char     magic[4];
  uint8_t  version;
  uint8_t  msgType;      // MSG_CONFIG
  uint8_t  distHalfFt;   // 1..16
  uint8_t  timeHalfMin;  // 1..10
  uint32_t seq;
};

struct BeaconAckMsg {
  char     magic[4];
  uint8_t  version;
  uint8_t  msgType;      // MSG_ACK
  uint32_t seq;
  uint8_t  ok;
};

struct BeaconPresenceMsg {
  char     magic[4];
  uint8_t  version;
  uint8_t  msgType;      // MSG_PRESENCE
  uint32_t seq;
  uint8_t  present;
  uint16_t distCm;
};

struct BeaconSuccessMsg {
  char     magic[4];
  uint8_t  version;
  uint8_t  msgType;      // MSG_SUCCESS
  uint32_t seq;
};
#pragma pack(pop)

// ====================== OLED CONFIG ======================
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(
  U8G2_R0,
  U8X8_PIN_NONE
);

static bool needsRedraw = true;

// ====================== AUDIO CONFIG ======================
static const int   SAMPLE_RATE     = 44100;
static const int   BITS_PER_SAMPLE = 16;
static const int16_t MAX_AMPL      = 22000;

static bool i2sOk = false;

// ====================== VOLUME ======================
static int volumeLevel = 5;      // 0–10
static const int VOL_MIN = 0;
static const int VOL_MAX = 10;

// ====================== UI SCREENS & EDIT MODES ======================
enum UiScreen {
  SCREEN_VOLUME = 0,
  SCREEN_TIME   = 1,
  SCREEN_ALARM  = 2,
  SCREEN_SENSOR_DIST = 3,
  SCREEN_SENSOR_TIME = 4,
  SCREEN_TEST   = 5
};
static const int NUM_SCREENS = 6;

enum EditMode {
  EDIT_NONE = 0,
  EDIT_TIME_HOUR,
  EDIT_TIME_MIN,
  EDIT_TIME_AMPM,
  EDIT_TIME_DOW,
  EDIT_ALARM_HOUR,
  EDIT_ALARM_MIN,
  EDIT_ALARM_AMPM,
  EDIT_ALARM_ENABLE,
  EDIT_SENSOR_DIST,
  EDIT_SENSOR_TIME
};

static UiScreen currentScreen = SCREEN_VOLUME;
static EditMode editMode      = EDIT_NONE;

// ====================== BUTTON / INPUT STATE ======================
static const int debounceMs              = 80;
static const unsigned long LONG_PRESS_MS = 700;

static bool lastModeState   = HIGH;
static unsigned long modePressStart = 0;

static bool lastUpState     = HIGH;
static bool lastDownState   = HIGH;

static unsigned long lastUpPressTime     = 0;
static unsigned long lastDownPressTime   = 0;

static unsigned long upPressStart        = 0;
static unsigned long downPressStart      = 0;

static unsigned long upLastRepeatTime    = 0;
static unsigned long downLastRepeatTime  = 0;

static bool upRepeating   = false;
static bool downRepeating = false;

static const unsigned long REPEAT_START_MS    = 500;
static const unsigned long REPEAT_INTERVAL_MS = 120;

// ====================== SLEEP / WAKE CONFIG ======================
static const uint32_t INACTIVITY_SLEEP_MS = 30000; // 30s
static uint32_t lastActivityMs = 0;
static inline void markActivity() { lastActivityMs = millis(); }

static uint64_t wakeMask() {
  return (1ULL << PIN_MODE) | (1ULL << PIN_VOL_UP) | (1ULL << PIN_VOL_DOWN);
}

static void printPinRtcInfo(const char* name, int pin) {
  bool valid = rtc_gpio_is_valid_gpio((gpio_num_t)pin);
  Serial.printf("RTC wake pin check: %s GPIO%d => %s\n", name, pin, valid ? "OK (RTC-capable)" : "NOT RTC-capable");
}

static void printWakeReason() {
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
  if (cause == ESP_SLEEP_WAKEUP_EXT1) {
    uint64_t status = esp_sleep_get_ext1_wakeup_status();
    if (status & (1ULL << PIN_MODE))     Serial.println("Wake: MODE");
    if (status & (1ULL << PIN_VOL_UP))   Serial.println("Wake: UP");
    if (status & (1ULL << PIN_VOL_DOWN)) Serial.println("Wake: DOWN");
  } else {
    Serial.printf("Wake cause: %d\n", (int)cause);
  }
}

// ====================== TIME / ALARM STATE (RTC stubbed) ======================
static uint8_t curHour = 7;   // 0–23
static uint8_t curMin  = 0;
static uint8_t curSec  = 0;
static uint8_t currentDayIndex = 0;

struct DayAlarm {
  bool    enabled;
  uint8_t hour24;
  uint8_t minute;
};
static DayAlarm alarms[7];
static uint8_t alarmDayCursor = 0;

// ====================== SENSOR SETTINGS (sent to beacon) ======================
static int sensorDistanceHalfFt = 2; // 1.0 ft
static const int SENSOR_DIST_MIN_HALF_FT = 1;
static const int SENSOR_DIST_MAX_HALF_FT = 16;

static int sensorTimeHalfMin = 1; // 0.5 min
static const int SENSOR_TIME_MIN_HALF_MIN = 1;
static const int SENSOR_TIME_MAX_HALF_MIN = 10;

static inline void incSensorDist() { if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) sensorDistanceHalfFt++; }
static inline void decSensorDist() { if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) sensorDistanceHalfFt--; }
static inline void incSensorTime() { if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) sensorTimeHalfMin++; }
static inline void decSensorTime() { if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) sensorTimeHalfMin--; }

static void formatHalfFt(char* out, size_t n, int halfFt) {
  int whole = halfFt / 2;
  bool half = (halfFt % 2) != 0;
  if (!half) snprintf(out, n, "%d ft", whole);
  else       snprintf(out, n, "%d.5 ft", whole);
}

static void formatHalfMin(char* out, size_t n, int halfMin) {
  int whole = halfMin / 2;
  bool half = (halfMin % 2) != 0;
  if (!half) snprintf(out, n, "%d min", whole);
  else       snprintf(out, n, "%d.5 min", whole);
}

// ====================== MELODY CONFIG ======================
struct Note { float freq; float duration; };

static const Note melody[] = {
  { 880.0f, 0.25f },
  { 1047.0f, 0.25f },
  { 1319.0f, 0.25f },
  { 1047.0f, 0.25f }
};

static const int   NUM_NOTES = sizeof(melody) / sizeof(melody[0]);
static const float NOTE_GAP_SEC     = 0.25f;
static const float ATTACK_FRACTION  = 0.10f;
static const float RELEASE_FRACTION = 0.20f;

static double melodyTimeSec  = 0.0;
static float  melodyTotalSec = 0.0f;
static float  oscPhase       = 0.0f;

static float computeMelodyTotalDuration() {
  float total = 0.0f;
  for (int i = 0; i < NUM_NOTES; i++) total += melody[i].duration + NOTE_GAP_SEC;
  return total;
}

static float noteEnvelope(float t, float noteDuration) {
  if (t < 0.0f || t > noteDuration) return 0.0f;

  float attack  = ATTACK_FRACTION  * noteDuration;
  float release = RELEASE_FRACTION * noteDuration;

  if (attack < 0.001f) attack = 0.001f;
  if (release < 0.001f) release = 0.001f;
  if (attack + release > noteDuration) {
    float scale = noteDuration / (attack + release);
    attack  *= scale;
    release *= scale;
  }

  if (t < attack) return t / attack;
  if (t > noteDuration - release) return (noteDuration - t) / release;
  return 1.0f;
}

static float getMelodySample() {
  if (melodyTotalSec <= 0.0f) return 0.0f;

  float tCycle = fmodf((float)melodyTimeSec, melodyTotalSec);

  float cursor = 0.0f;
  for (int i = 0; i < NUM_NOTES; i++) {
    float segment = melody[i].duration + NOTE_GAP_SEC;

    if (tCycle < cursor + segment) {
      float local = tCycle - cursor;

      if (local > melody[i].duration) return 0.0f;

      float env  = noteEnvelope(local, melody[i].duration);
      float freq = melody[i].freq;

      float phaseInc = (float)(TWO_PI * freq / (float)SAMPLE_RATE);
      oscPhase += phaseInc;
      if (oscPhase >= TWO_PI) oscPhase -= TWO_PI;

      float s1 = sinf(oscPhase);
      float s2 = sinf(2.0f * oscPhase);
      float mixed = 0.9f * s1 + 0.1f * s2;

      return env * mixed;
    }
    cursor += segment;
  }

  return 0.0f;
}

// ====================== FLASHING CURSOR STATE ======================
static bool flashState = true;
static unsigned long lastFlashToggleMs = 0;
static const unsigned long FLASH_INTERVAL_MS = 500;

static void updateFlashState() {
  if (editMode == EDIT_NONE) { flashState = true; return; }
  unsigned long now = millis();
  if (now - lastFlashToggleMs >= FLASH_INTERVAL_MS) {
    lastFlashToggleMs = now;
    flashState = !flashState;
    needsRedraw = true;
  }
}

// ====================== ALARM RINGING (scheduled alarm) ======================
static const uint32_t ALARM_RING_MS = 30000;
static bool     alarmRinging = false;
static uint32_t alarmRingingUntilMs = 0;

static inline bool audioShouldRun(); // forward

static void startAlarmRinging() {
  alarmRinging = true;
  alarmRingingUntilMs = millis() + ALARM_RING_MS;
  melodyTimeSec = 0.0;
  oscPhase = 0.0f;
  needsRedraw = true;
}

static void stopAlarmRinging() {
  alarmRinging = false;
  if (i2sOk && !audioShouldRun()) i2s_zero_dma_buffer(I2S_PORT);
  needsRedraw = true;
}

// ====================== TEST SESSION STATE ======================
static bool       espNowOk = false;
static uint32_t   cfgSeq   = 0;

static bool       testSessionActive  = false;
static bool       testWaitingAck     = false;
static bool       testSoundOn        = false;
static TestStatus testStatus         = TEST_STATUS_NONE;
static uint32_t   testSeq            = 0;
static uint32_t   testAckDeadlineMs  = 0;

static const uint32_t TEST_ACK_TIMEOUT_MS       = 1200;
static const uint32_t TEST_STATUS_DISPLAY_MS    = 5000; // auto-clear
static uint32_t       testStatusSetMs           = 0;

static const uint32_t PRESENCE_LOSS_HOLD_MS     = 5000; // sustained loss required
static uint32_t       presenceLossPendingMs     = 0;

static inline bool testIsRunning() { return testSessionActive; }

static void setTestStatus(TestStatus s) {
  testStatus = s;
  testStatusSetMs = millis();
  needsRedraw = true;
}

static void clearTestStatus() {
  if (testStatus != TEST_STATUS_NONE) {
    testStatus = TEST_STATUS_NONE;
    needsRedraw = true;
  }
}

static void endTestSessionReturnToStart(TestStatus finalStatus) {
  markActivity();
  testSessionActive = false;
  testWaitingAck = false;
  testSoundOn = false;
  presenceLossPendingMs = 0;
  setTestStatus(finalStatus); // clears after 5s
}

static inline bool audioShouldRun() {
  return alarmRinging || (testSessionActive && testSoundOn);
}

// ====================== OLED DRAW HELPERS ======================
static const int TITLE_Y = 24;
static const int VALUE_Y = 44;
static const int DOW_Y   = 60;

static const char dayChars[7] = { 'S','M','T','W','T','F','S' };

static void getTime12(uint8_t hour24, uint8_t &outHour12, bool &outIsPm) {
  if (hour24 == 0)      { outHour12 = 12; outIsPm = false; }
  else if (hour24 < 12) { outHour12 = hour24; outIsPm = false; }
  else if (hour24 == 12){ outHour12 = 12; outIsPm = true; }
  else                  { outHour12 = hour24 - 12; outIsPm = true; }
}

static void drawTimeLikeValue(uint8_t hour24, uint8_t minute,
                              bool showAmPm,
                              bool selHour, bool selMin, bool selAmPm) {
  uint8_t h12; bool isPm;
  getTime12(hour24, h12, isPm);

  char hh[3], mm[3], ampm[3];
  snprintf(hh, sizeof(hh), "%02u", (unsigned)h12);
  snprintf(mm, sizeof(mm), "%02u", (unsigned)minute);
  snprintf(ampm, sizeof(ampm), "%s", isPm ? "PM" : "AM");

  u8g2.setFont(u8g2_font_9x18B_tr);

  int wHH    = u8g2.getStrWidth(hh);
  int wColon = u8g2.getStrWidth(":");
  int wMM    = u8g2.getStrWidth(mm);
  int wSpace = u8g2.getStrWidth(" ");
  int wAMPM  = showAmPm ? u8g2.getStrWidth(ampm) : 0;

  int totalWidth = wHH + wColon + wMM + (showAmPm ? (wSpace + wAMPM) : 0);
  int x = (128 - totalWidth) / 2;

  if (!(selHour && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(hh); }
  x += wHH;

  u8g2.setCursor(x, VALUE_Y); u8g2.print(":");
  x += wColon;

  if (!(selMin && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(mm); }
  x += wMM;

  if (showAmPm) {
    u8g2.setCursor(x, VALUE_Y); u8g2.print(" ");
    x += wSpace;
    if (!(selAmPm && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(ampm); }
  }
}

static void drawCenteredSmallTextWrapped(const char* txt) {
  if (!txt || txt[0] == '\0') return;

  u8g2.setFont(u8g2_font_5x8_tr);

  int w = u8g2.getStrWidth(txt);
  if (w <= 128) {
    int x = (128 - w) / 2;
    u8g2.setCursor(x, 62);
    u8g2.print(txt);
    return;
  }

  const int n = (int)strlen(txt);
  int mid = n / 2;
  int split = -1;
  for (int i = 0; i < n; i++) {
    int idx = (mid + i < n) ? (mid + i) : -1;
    if (idx >= 0 && txt[idx] == ' ') { split = idx; break; }
    idx = (mid - i >= 0) ? (mid - i) : -1;
    if (idx >= 0 && txt[idx] == ' ') { split = idx; break; }
  }
  if (split < 0) split = mid;

  char line1[64]; char line2[64];
  int l1 = min(split, (int)sizeof(line1) - 1);
  memcpy(line1, txt, l1);
  line1[l1] = '\0';

  int start2 = split;
  while (start2 < n && txt[start2] == ' ') start2++;

  int l2 = min(n - start2, (int)sizeof(line2) - 1);
  memcpy(line2, txt + start2, l2);
  line2[l2] = '\0';

  int w1 = u8g2.getStrWidth(line1);
  int w2 = u8g2.getStrWidth(line2);

  u8g2.setCursor((128 - w1) / 2, 56);
  u8g2.print(line1);

  u8g2.setCursor((128 - w2) / 2, 64);
  u8g2.print(line2);
}

static void updateDisplay() {
  u8g2.clearBuffer();

  const char* title = "";
  switch (currentScreen) {
    case SCREEN_VOLUME:       title = "Volume";                break;
    case SCREEN_TIME:         title = "Time";                  break;
    case SCREEN_ALARM:        title = "Alarm";                 break;
    case SCREEN_SENSOR_DIST:  title = "Sensor Distance (Max)"; break;
    case SCREEN_SENSOR_TIME:  title = "Sensor Time (Min)";     break;
    case SCREEN_TEST:         title = "Test";                  break;
  }

  u8g2.setFont(u8g2_font_6x12_tr);
  int titleWidth = u8g2.getStrWidth(title);
  u8g2.setCursor((128 - titleWidth) / 2, TITLE_Y);
  u8g2.print(title);

  if (currentScreen == SCREEN_VOLUME) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%d/%d", volumeLevel, VOL_MAX);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_TIME) {
    bool selHour  = (editMode == EDIT_TIME_HOUR);
    bool selMin   = (editMode == EDIT_TIME_MIN);
    bool selAmPm  = (editMode == EDIT_TIME_AMPM);
    drawTimeLikeValue(curHour, curMin, true, selHour, selMin, selAmPm);
  }
  else if (currentScreen == SCREEN_ALARM) {
    DayAlarm &da = alarms[alarmDayCursor];
    bool selHour  = (editMode == EDIT_ALARM_HOUR);
    bool selMin   = (editMode == EDIT_ALARM_MIN);
    bool selAmPm  = (editMode == EDIT_ALARM_AMPM);
    drawTimeLikeValue(da.hour24, da.minute, true, selHour, selMin, selAmPm);
  }
  else if (currentScreen == SCREEN_SENSOR_DIST) {
    char buf[16];
    formatHalfFt(buf, sizeof(buf), sensorDistanceHalfFt);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_SENSOR_TIME) {
    char buf[16];
    formatHalfMin(buf, sizeof(buf), sensorTimeHalfMin);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_TEST) {
    const char* btn = testIsRunning() ? "Stop" : "Start";
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(btn);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(btn);

    drawCenteredSmallTextWrapped(testStatusToText(testStatus));
  }

  if (alarmRinging) {
    u8g2.setFont(u8g2_font_6x12_tr);
    u8g2.setCursor(2, 12);
    u8g2.print("RING");
  }

  u8g2.sendBuffer();
}

// ====================== I2S SETUP ======================
static bool setupI2S() {
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 128,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };

  if (i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL) != ESP_OK) return false;

  i2s_pin_config_t pin_config = {
    .bck_io_num   = GPIO_I2S_BCLK,
    .ws_io_num    = GPIO_I2S_LRCLK,
    .data_out_num = GPIO_I2S_DATA,
    .data_in_num  = I2S_PIN_NO_CHANGE
  };

  if (i2s_set_pin(I2S_PORT, &pin_config) != ESP_OK) return false;

  if (i2s_set_clk(I2S_PORT, SAMPLE_RATE,
                  I2S_BITS_PER_SAMPLE_16BIT,
                  I2S_CHANNEL_STEREO) != ESP_OK) return false;

  return true;
}

// ====================== ESPNOW SEND / SETUP ======================
static void sendBeaconConfig(const char* reason, uint32_t seqToSend) {
  if (!espNowOk) return;

  BeaconCfgMsg msg{};
  memcpy(msg.magic, MAGIC_ROOS, 4);
  msg.version  = PROTO_VER;
  msg.msgType  = MSG_CONFIG;
  msg.distHalfFt  = (uint8_t)sensorDistanceHalfFt;
  msg.timeHalfMin = (uint8_t)sensorTimeHalfMin;
  msg.seq = seqToSend;

  esp_err_t err = esp_now_send(BEACON_MAC, (uint8_t*)&msg, sizeof(msg));
  Serial.printf("TX CONFIG (%s): distHalfFt=%u timeHalfMin=%u seq=%u err=%d\n",
                reason, (unsigned)msg.distHalfFt, (unsigned)msg.timeHalfMin,
                (unsigned)msg.seq, (int)err);
}

#if ESP_IDF_VERSION_MAJOR >= 5
static void onEspNowSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  (void)info;
  Serial.printf("ESP-NOW send => %s\n", status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
}
static void onEspNowRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  (void)info;
#else
static void onEspNowSent(const uint8_t *mac, esp_now_send_status_t status) {
  (void)mac;
  Serial.printf("ESP-NOW send => %s\n", status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
}
static void onEspNowRecv(const uint8_t *mac, const uint8_t *data, int len) {
  (void)mac;
#endif
  if (!data || len < 6) return;
  if (memcmp(data, MAGIC_ROOS, 4) != 0) return;
  if (data[4] != PROTO_VER) return;

  const uint8_t type = data[5];

  if (type == MSG_ACK) {
    if (len != (int)sizeof(BeaconAckMsg)) return;
    BeaconAckMsg m{};
    memcpy(&m, data, sizeof(m));
    Serial.printf("RX ACK seq=%u ok=%u\n", (unsigned)m.seq, (unsigned)m.ok);

    if (testSessionActive && testWaitingAck && m.seq == testSeq) {
      if (m.ok == 1) {
        testWaitingAck = false;
        if (testStatus == TEST_STATUS_ERROR) clearTestStatus();
      } else {
        endTestSessionReturnToStart(TEST_STATUS_ERROR);
      }
    }
  }
  else if (type == MSG_PRESENCE) {
    if (len != (int)sizeof(BeaconPresenceMsg)) return;
    BeaconPresenceMsg m{};
    memcpy(&m, data, sizeof(m));

    if (!(testSessionActive && m.seq == testSeq)) return;

    const uint32_t now = millis();

    if (m.present) {
      // Immediate silence on presence
      testSoundOn = false;
      presenceLossPendingMs = 0;
      setTestStatus(TEST_STATUS_PRESENCE_DETECTED);
    } else {
      // Resume sound only after sustained loss
      if (presenceLossPendingMs == 0) presenceLossPendingMs = now;
      if (now - presenceLossPendingMs >= PRESENCE_LOSS_HOLD_MS) {
        if (!testSoundOn) {
          testSoundOn = true;
          setTestStatus(TEST_STATUS_PRESENCE_LOST);
        }
      }
    }
  }
  else if (type == MSG_SUCCESS) {
    if (len != (int)sizeof(BeaconSuccessMsg)) return;
    BeaconSuccessMsg m{};
    memcpy(&m, data, sizeof(m));
    Serial.printf("RX SUCCESS seq=%u\n", (unsigned)m.seq);

    if (testSessionActive && m.seq == testSeq) {
      endTestSessionReturnToStart(TEST_STATUS_SUCCESS);
    }
  }
}

static bool setupEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  esp_wifi_set_ps(WIFI_PS_NONE);

  WiFi.disconnect(false, true);
  delay(50);

  esp_err_t s = esp_wifi_start();
  Serial.printf("esp_wifi_start => %d\n", (int)s);

  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  if (esp_now_init() != ESP_OK) return false;

  esp_now_register_send_cb(onEspNowSent);
  esp_now_register_recv_cb(onEspNowRecv);

  esp_now_peer_info_t peer{};
  memcpy(peer.peer_addr, BEACON_MAC, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;

  if (!esp_now_is_peer_exist(BEACON_MAC)) {
    if (esp_now_add_peer(&peer) != ESP_OK) return false;
  }
  return true;
}

// ====================== TEST SESSION CONTROL ======================
static void startTestSession() {
  markActivity();

  if (!espNowOk) {
    endTestSessionReturnToStart(TEST_STATUS_ERROR);
    return;
  }

  testSessionActive = true;
  testWaitingAck = true;
  testSoundOn = true;
  presenceLossPendingMs = 0;
  clearTestStatus();

  testSeq = ++cfgSeq;
  testAckDeadlineMs = millis() + TEST_ACK_TIMEOUT_MS;

  melodyTimeSec = 0.0;
  oscPhase = 0.0f;

  sendBeaconConfig("test_start", testSeq);
  needsRedraw = true;
}

static void stopTestSessionManual() {
  markActivity();
  testSessionActive = false;
  testWaitingAck = false;
  testSoundOn = false;
  presenceLossPendingMs = 0;
  clearTestStatus();
  needsRedraw = true;
}

static void updateTestSession() {
  // auto-clear message after 5s (even if not running)
  if (testStatus != TEST_STATUS_NONE && (millis() - testStatusSetMs) >= TEST_STATUS_DISPLAY_MS) {
    clearTestStatus();
  }

  if (!testSessionActive) return;

  if (testWaitingAck && (int32_t)(millis() - testAckDeadlineMs) >= 0) {
    endTestSessionReturnToStart(TEST_STATUS_ERROR);
  }
}

// ====================== INPUT HANDLERS ======================
static void handleTestToggleStartStop() {
  if (testSessionActive) stopTestSessionManual();
  else startTestSession();
}

static void handleModeShortPress() {
  markActivity();

  if (editMode == EDIT_NONE) {
    if (currentScreen == SCREEN_TEST && testSessionActive) {
      stopTestSessionManual();
    }

    UiScreen next = (UiScreen)((currentScreen + 1) % NUM_SCREENS);
    if (next == SCREEN_ALARM) alarmDayCursor = currentDayIndex;
    currentScreen = next;
  } else {
    editMode = EDIT_NONE;
  }

  needsRedraw = true;
}

static void handleModeLongPress() {
  markActivity();

  if (editMode != EDIT_NONE) editMode = EDIT_NONE;
  else {
    switch (currentScreen) {
      case SCREEN_TIME:        editMode = EDIT_TIME_HOUR;    break;
      case SCREEN_ALARM:       editMode = EDIT_ALARM_HOUR;   break;
      case SCREEN_SENSOR_DIST: editMode = EDIT_SENSOR_DIST;  break;
      case SCREEN_SENSOR_TIME: editMode = EDIT_SENSOR_TIME;  break;
      default: break;
    }
  }

  needsRedraw = true;
}

static void handleUpShortPress() {
  bool changed = false;

  if (editMode == EDIT_NONE) {
    if (currentScreen == SCREEN_TEST) { handleTestToggleStartStop(); return; }

    switch (currentScreen) {
      case SCREEN_VOLUME:
        if (volumeLevel < VOL_MAX) { volumeLevel++; changed = true; }
        break;
      case SCREEN_SENSOR_DIST:
        if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; }
        break;
      case SCREEN_SENSOR_TIME:
        if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; }
        break;
      default: break;
    }
  } else {
    switch (editMode) {
      case EDIT_SENSOR_DIST:
        if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; }
        break;
      case EDIT_SENSOR_TIME:
        if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; }
        break;
      default: break;
    }
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void handleDownShortPress() {
  bool changed = false;

  if (editMode == EDIT_NONE) {
    if (currentScreen == SCREEN_TEST) { handleTestToggleStartStop(); return; }

    switch (currentScreen) {
      case SCREEN_VOLUME:
        if (volumeLevel > VOL_MIN) { volumeLevel--; changed = true; }
        break;
      case SCREEN_SENSOR_DIST:
        if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; }
        break;
      case SCREEN_SENSOR_TIME:
        if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; }
        break;
      default: break;
    }
  } else {
    switch (editMode) {
      case EDIT_SENSOR_DIST:
        if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; }
        break;
      case EDIT_SENSOR_TIME:
        if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; }
        break;
      default: break;
    }
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void readButtons() {
  unsigned long now = millis();

  // MODE
  bool modeState = digitalRead(PIN_MODE);
  if (modeState == LOW && lastModeState == HIGH) {
    markActivity();
    modePressStart = now;
  }
  if (modeState == HIGH && lastModeState == LOW) {
    unsigned long pressDuration = now - modePressStart;
    if (pressDuration >= LONG_PRESS_MS) handleModeLongPress();
    else if (pressDuration > (unsigned long)debounceMs) handleModeShortPress();
  }
  lastModeState = modeState;

  // UP
  bool upState = digitalRead(PIN_VOL_UP);
  if (upState == LOW && lastUpState == HIGH) {
    markActivity();
    if (now - lastUpPressTime > (unsigned long)debounceMs) {
      upPressStart     = now;
      upLastRepeatTime = now;
      upRepeating      = false;
      handleUpShortPress();
      lastUpPressTime  = now;
    }
  }
  lastUpState = upState;

  // DOWN
  bool downState = digitalRead(PIN_VOL_DOWN);
  if (downState == LOW && lastDownState == HIGH) {
    markActivity();
    if (now - lastDownPressTime > (unsigned long)debounceMs) {
      downPressStart     = now;
      downLastRepeatTime = now;
      downRepeating      = false;
      handleDownShortPress();
      lastDownPressTime  = now;
    }
  }
  lastDownState = downState;
}

// ====================== SETUP ======================
void setup() {
  Serial.begin(115200);
  delay(300);

  printWakeReason();
  printPinRtcInfo("MODE", PIN_MODE);
  printPinRtcInfo("UP",   PIN_VOL_UP);
  printPinRtcInfo("DOWN", PIN_VOL_DOWN);

  lastActivityMs = millis();

  pinMode(PIN_VOL_UP,   INPUT_PULLUP);
  pinMode(PIN_VOL_DOWN, INPUT_PULLUP);
  pinMode(PIN_MODE,     INPUT_PULLUP);

  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);

  u8g2.begin();
  u8g2.setPowerSave(0);

  for (int i = 0; i < 7; i++) {
    alarms[i].enabled = false;
    alarms[i].hour24  = 7;
    alarms[i].minute  = 0;
  }

  i2sOk = setupI2S();
  Serial.println(i2sOk ? "I2S OK" : "I2S FAIL");

  melodyTotalSec = computeMelodyTotalDuration();

  melodyTimeSec      = 0.0;
  oscPhase           = 0.0f;
  lastFlashToggleMs  = millis();

  testSessionActive = false;
  testWaitingAck = false;
  testSoundOn = false;
  testStatus = TEST_STATUS_NONE;
  testSeq = 0;
  presenceLossPendingMs = 0;

  Serial.print("Cube WiFi.macAddress() = ");
  Serial.println(WiFi.macAddress());

  espNowOk = setupEspNow();
  Serial.println(espNowOk ? "ESP-NOW OK" : "ESP-NOW FAIL");

  needsRedraw = true;
}

// ====================== MAIN LOOP ======================
void loop() {
  updateTestSession();
  updateFlashState();
  readButtons();

  if (needsRedraw) {
    updateDisplay();
    needsRedraw = false;
  }

  // If no audio, don't waste CPU
  if (!audioShouldRun()) {
    delay(10);
    return;
  }

  if (!i2sOk) return;

  const int FRAMES = 128;
  int16_t samples[FRAMES * 2];

  float volumeScale = volumeLevel / 10.0f;
  if (volumeScale < 0.0f) volumeScale = 0.0f;

  for (int i = 0; i < FRAMES; i++) {
    float s = getMelodySample();
    melodyTimeSec += 1.0 / (double)SAMPLE_RATE;

    int16_t sample16 = (int16_t)(s * MAX_AMPL * volumeScale);
    samples[2 * i]     = sample16;
    samples[2 * i + 1] = sample16;
  }

  size_t bytesWritten;
  i2s_write(I2S_PORT, (const char*)samples, sizeof(samples), &bytesWritten, portMAX_DELAY);
}