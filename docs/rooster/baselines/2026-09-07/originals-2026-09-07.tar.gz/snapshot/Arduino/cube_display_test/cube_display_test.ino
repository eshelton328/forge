// cube_oled_gpio7_pmos_gate.ino  (ESP32-S3 Cube)
//
// Minimal OLED test that:
//  - Powers the OLED via PMOS gate using GPIO7
//  - Uses SSD1306 128x64 @ I2C address 0x3C
//  - SDA=GPIO8, SCL=GPIO9
//  - Logs button presses on MODE/UP/DOWN
//
// Wiring assumptions:
//  - OLED GND -> GND
//  - OLED VCC/VIN -> switched 3.3V output of your PMOS power gate
//  - OLED SDA -> GPIO8
//  - OLED SCL -> GPIO9
//  - GPIO7 -> your PMOS gate driver input (often via NPN), so "ON" enables OLED power
//
// If your gate logic is inverted, flip OLED_PWR_ACTIVE_HIGH to 0.

#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>

// ---------------- Pins ----------------
#define PIN_MODE       4
#define PIN_VOL_UP     5
#define PIN_VOL_DOWN   6

#define OLED_SDA_PIN   8
#define OLED_SCL_PIN   9

// PMOS gate control
#define PIN_OLED_PWR   7
#define OLED_PWR_ACTIVE_HIGH 1   // set to 0 if LOW = ON in your gate chain

// ---------------- OLED (SSD1306) ----------------
U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);
static bool oledReady = false;

// ---------------- Button debounce ----------------
static const uint32_t DEBOUNCE_MS = 80;
static bool lastMode = HIGH, lastUp = HIGH, lastDown = HIGH;
static uint32_t lastModeEdgeMs = 0, lastUpEdgeMs = 0, lastDownEdgeMs = 0;

// ---------------- UI / test ----------------
static uint32_t lastDrawMs = 0;
static uint32_t counterVal = 0;

static inline void oledPower(bool on) {
  if (OLED_PWR_ACTIVE_HIGH) digitalWrite(PIN_OLED_PWR, on ? HIGH : LOW);
  else                      digitalWrite(PIN_OLED_PWR, on ? LOW  : HIGH);
}

static void i2cScanOnce() {
  Serial.println("[I2C] scan...");
  int found = 0;
  for (uint8_t addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    uint8_t err = Wire.endTransmission();
    if (err == 0) {
      Serial.print("  ACK @ 0x");
      if (addr < 16) Serial.print("0");
      Serial.println(addr, HEX);
      found++;
      delay(2);
    }
  }
  Serial.print("[I2C] found=");
  Serial.println(found);
}

static void ensureOledReady() {
  if (oledReady) return;

  // Turn OLED power on and give it time to come up
  oledPower(true);
  delay(40);

  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
  Wire.setClock(100000);

  i2cScanOnce();

  u8g2.begin();          // uses HW I2C (Wire)
  u8g2.setPowerSave(0);
  oledReady = true;

  Serial.println("[OLED] u8g2.begin() done");
}

static void drawFrame() {
  if (!oledReady) return;

  u8g2.clearBuffer();

  u8g2.setFont(u8g2_font_6x12_tr);
  u8g2.setCursor(0, 12);
  u8g2.print("OLED POWER-GATED via GPIO7");

  u8g2.setCursor(0, 28);
  u8g2.print("I2C SDA=8 SCL=9 addr=0x3C");

  u8g2.setFont(u8g2_font_9x18B_tr);
  u8g2.setCursor(0, 56);
  u8g2.print("CNT ");
  u8g2.print(counterVal);

  u8g2.sendBuffer();
}

static void logButtons() {
  uint32_t now = millis();

  bool mode = digitalRead(PIN_MODE);
  bool up   = digitalRead(PIN_VOL_UP);
  bool down = digitalRead(PIN_VOL_DOWN);

  if (mode != lastMode && (now - lastModeEdgeMs) > DEBOUNCE_MS) {
    lastModeEdgeMs = now;
    lastMode = mode;
    if (mode == LOW) Serial.println("[BTN] MODE down");
    else             Serial.println("[BTN] MODE up");
  }

  if (up != lastUp && (now - lastUpEdgeMs) > DEBOUNCE_MS) {
    lastUpEdgeMs = now;
    lastUp = up;
    if (up == LOW) Serial.println("[BTN] UP down");
    else           Serial.println("[BTN] UP up");
  }

  if (down != lastDown && (now - lastDownEdgeMs) > DEBOUNCE_MS) {
    lastDownEdgeMs = now;
    lastDown = down;
    if (down == LOW) Serial.println("[BTN] DOWN down");
    else             Serial.println("[BTN] DOWN up");
  }
}

void setup() {
  Serial.begin(115200);
  delay(200);

  Serial.println("\n[BOOT] starting");

  pinMode(PIN_MODE,     INPUT_PULLUP);
  pinMode(PIN_VOL_UP,   INPUT_PULLUP);
  pinMode(PIN_VOL_DOWN, INPUT_PULLUP);

  pinMode(PIN_OLED_PWR, OUTPUT);
  oledPower(false);                 // start OFF (avoid partial-power weirdness)
  delay(50);

  ensureOledReady();
  counterVal = 0;
  drawFrame();
  lastDrawMs = millis();

  Serial.println("[BOOT] ready (press buttons to see logs)");
}

void loop() {
  logButtons();

  // redraw once per second so you can confirm it's alive
  uint32_t now = millis();
  if (now - lastDrawMs >= 1000) {
    lastDrawMs = now;
    counterVal++;
    drawFrame();
    Serial.print("[LOOP] alive cnt=");
    Serial.println(counterVal);
  }

  delay(5);
}