// cube_rooster_clock.ino  (ESP32-S3 Cube)
//
// Combined:
//   ✅ Time/Alarm UI + behavior (from your working sketch)
//   ✅ Settings persistence (NVS blob + CRC)
//   ✅ Working Test Mode (Presence Detected / Lost / Success) + always-stoppable
//   ✅ SAFE ESP-NOW RX: callbacks only set flags; loop() processes transitions
//   ✅ Deep sleep wake for scheduled alarm using RV-3028 INT -> ESP32-S3 GPIO1
//
// NEW (for Beacon session gating):
//   ✅ Send STOP(seq) to Beacon whenever a session ends (success/manual/timeout)
//      so Beacon can stop transmitting immediately without relying on timeouts.
//
// Single-file sketch (no tabs).

// ---- minimal fixed-size types (avoid relying on Arduino.h before includes) ----
typedef unsigned char  roos_u8;
typedef unsigned short roos_u16;
typedef unsigned long  roos_u32;

// ====================== SETTINGS TYPES (MUST BE ABOVE INCLUDES) ======================
#pragma pack(push, 1)
struct PersistAlarm {
  roos_u8 enabled;
  roos_u8 hour24;
  roos_u8 minute;
};

struct SettingsBlob {
  roos_u32 magic;
  roos_u16 ver;
  roos_u8  volume;
  roos_u8  distHalfFt;
  roos_u8  timeHalfMin;
  PersistAlarm alarms[7];
  roos_u32 crc32;
};
#pragma pack(pop)

// ---- shared session kinds ----
enum SessionKind : roos_u8 {
  SESSION_NONE  = 0,
  SESSION_TEST  = 1,
  SESSION_ALARM = 2
};

// ---- test status (UI only) ----
enum TestStatus : roos_u8 {
  TEST_STATUS_NONE = 0,
  TEST_STATUS_ERROR,
  TEST_STATUS_PRESENCE_DETECTED,
  TEST_STATUS_PRESENCE_LOST,
  TEST_STATUS_SUCCESS,
  TEST_STATUS_AUDIO_ONLY
};

// ---- ESP-NOW message types ----
enum MsgType : roos_u8 {
  MSG_CONFIG   = 1,
  MSG_ACK      = 2,
  MSG_PRESENCE = 3,
  MSG_SUCCESS  = 4,
  MSG_STOP     = 5
};

#pragma pack(push, 1)
struct BeaconCfgMsg {
  char     magic[4];        // "ROOS"
  roos_u8  version;         // 1
  roos_u8  msgType;         // 1=config
  roos_u8  distHalfFt;      // 1..16 (0.5..8.0 ft)
  roos_u8  timeHalfMin;     // 1..10 (0.5..5.0 min)
  roos_u32 seq;             // incrementing
};

struct BeaconAckMsg {
  char     magic[4];
  roos_u8  version;
  roos_u8  msgType;         // 2=ack
  roos_u32 seq;             // echoes config seq
  roos_u8  ok;              // 1=accepted, 0=bad
};

struct BeaconPresenceMsg {
  char     magic[4];
  roos_u8  version;
  roos_u8  msgType;         // 3=presence
  roos_u32 seq;             // current config seq (or 0 if none yet)
  roos_u8  present;         // 0/1
  roos_u16 distCm;          // 0 if unknown
};

struct BeaconSuccessMsg {
  char     magic[4];
  roos_u8  version;
  roos_u8  msgType;         // 4=success
  roos_u32 seq;             // current config seq
};

struct BeaconStopMsg {
  char     magic[4];
  roos_u8  version;
  roos_u8  msgType;         // 5=stop
  roos_u32 seq;             // session/config seq to stop
};
#pragma pack(pop)

// ============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include "driver/i2s.h"
#include <math.h>

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_wifi_types.h>

// (Optional; safe on modern cores)
#ifdef __has_include
  #if __has_include("esp_idf_version.h")
    #include "esp_idf_version.h"
  #endif
#endif

#include <nvs.h>
#include <nvs_flash.h>
#include <stddef.h>
#include <string.h>

#include "esp_sleep.h"
#include "driver/rtc_io.h"

#ifndef ESP_IDF_VERSION_MAJOR
#define ESP_IDF_VERSION_MAJOR 5
#endif

#ifndef TWO_PI
#define TWO_PI 6.28318530717958647692f
#endif

// ====================== PIN SELECTION FOR ESP32-S3 ======================
#define GPIO_I2S_BCLK    15
#define GPIO_I2S_LRCLK   16
#define GPIO_I2S_DATA    17

#define PIN_VOL_UP       5
#define PIN_VOL_DOWN     6
#define PIN_MODE         4

#define OLED_SDA_PIN     8
#define OLED_SCL_PIN     9

#define I2S_PORT         I2S_NUM_0

// ===== RTC INT -> ESP32-S3 GPIO1 (wake from deep sleep) =====
#define PIN_RTC_INT      1   // RTC INT pin wired here (active-low open-drain)

// ====================== OPTIONAL HARD MUTE ======================
#define USE_AUDIO_MUTE_PIN 0
#define PIN_AUDIO_MUTE     18
#define AUDIO_MUTE_ACTIVE_HIGH 1

static inline void audioMute(bool mute) {
#if USE_AUDIO_MUTE_PIN
  if (AUDIO_MUTE_ACTIVE_HIGH) digitalWrite(PIN_AUDIO_MUTE, mute ? HIGH : LOW);
  else                        digitalWrite(PIN_AUDIO_MUTE, mute ? LOW : HIGH);
#else
  (void)mute;
#endif
}

// ====================== ESP-NOW CONFIG ======================
static const uint8_t ESPNOW_CHANNEL = 9; // must match Beacon

// Put your Beacon STA MAC here:
static uint8_t BEACON_MAC[6] = { 0x40, 0x4C, 0xCA, 0x3C, 0x51, 0xA4 };

static const char    MAGIC_ROOS[4] = { 'R','O','O','S' };
static const uint8_t PROTO_VER     = 1;

static bool     espNowOk = false;
static uint32_t cfgSeq   = 0;

// ====================== OLED CONFIG ======================
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

// ====================== AUDIO CONFIG ======================
const int   SAMPLE_RATE     = 44100;
const int   BITS_PER_SAMPLE = 16;
const int16_t MAX_AMPL      = 22000;

// ====================== VOLUME ======================
int volumeLevel = 5;      // 0–10
const int VOL_MIN = 0;
const int VOL_MAX = 10;

// ====================== UI SCREENS & EDIT MODES ======================
enum UiScreen : uint8_t {
  SCREEN_TIME        = 0,
  SCREEN_ALARM       = 1,
  SCREEN_VOLUME      = 2,
  SCREEN_SENSOR_TIME = 3,
  SCREEN_SENSOR_DIST = 4,
  SCREEN_TEST        = 5
};
const int NUM_SCREENS = 6;

enum EditMode : uint8_t {
  EDIT_NONE = 0,
  EDIT_TIME_HOUR,
  EDIT_TIME_MIN,
  EDIT_TIME_AMPM,
  EDIT_TIME_DOW,
  EDIT_ALARM_HOUR,
  EDIT_ALARM_MIN,
  EDIT_ALARM_AMPM,
  EDIT_ALARM_ENABLE,
  EDIT_SENSOR_DIST,
  EDIT_SENSOR_TIME
};

UiScreen currentScreen = SCREEN_TIME;
EditMode editMode      = EDIT_NONE;

bool needsRedraw = true;

// ====================== TIME / ALARM STATE ======================
uint8_t curHour = 7;   // 0–23
uint8_t curMin  = 0;
uint8_t curSec  = 0;

// Current day of week: 0=Sun..6=Sat
uint8_t currentDayIndex = 0;

// Per-day alarms
struct DayAlarm {
  bool    enabled;
  uint8_t hour24;
  uint8_t minute;
};

DayAlarm alarms[7];
uint8_t alarmDayCursor = 0;

// Prevent re-triggering (while awake)
int lastAlarmTriggerKey = -1;
static int makeAlarmTriggerKey() {
  return (int)currentDayIndex * 24 * 60 + (int)curHour * 60 + (int)curMin;
}

// ====================== SENSOR SETTINGS ======================
int sensorDistanceHalfFt = 2;  // 1.0 ft
static const int SENSOR_DIST_MIN_HALF_FT = 1;
static const int SENSOR_DIST_MAX_HALF_FT = 16;

int sensorTimeHalfMin = 1;     // 0.5 min
static const int SENSOR_TIME_MIN_HALF_MIN = 1;
static const int SENSOR_TIME_MAX_HALF_MIN = 10;

static inline void incSensorDist() { if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) sensorDistanceHalfFt++; }
static inline void decSensorDist() { if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) sensorDistanceHalfFt--; }
static inline void incSensorTime() { if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) sensorTimeHalfMin++; }
static inline void decSensorTime() { if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) sensorTimeHalfMin--; }

static void formatHalfFt(char* out, size_t n, int halfFt) {
  int whole = halfFt / 2;
  bool half = (halfFt % 2) != 0;
  if (!half) snprintf(out, n, "%d ft", whole);
  else       snprintf(out, n, "%d.5 ft", whole);
}

static void formatHalfMin(char* out, size_t n, int halfMin) {
  int whole = halfMin / 2;
  bool half = (halfMin % 2) != 0;
  if (!half) snprintf(out, n, "%d min", whole);
  else       snprintf(out, n, "%d.5 min", whole);
}

// ====================== SETTINGS PERSISTENCE (NVS) ======================
static bool settingsDirty = false;
static uint32_t settingsDirtySinceMs = 0;
static const uint32_t SETTINGS_COMMIT_DELAY_MS = 750;

// RTC alarm programming is only done when needed (and always before deep sleep)
static bool rtcAlarmNeedsUpdate = true;
static uint32_t rtcLastProgramMs = 0;

static inline void settingsMarkDirty() {
  if (!settingsDirty) settingsDirtySinceMs = millis();
  settingsDirty = true;
  rtcAlarmNeedsUpdate = true;
}

static void settingsApplyDefaults() {
  volumeLevel = 5;
  sensorDistanceHalfFt = 2;
  sensorTimeHalfMin = 1;

  for (int i = 0; i < 7; i++) {
    alarms[i].enabled = false;
    alarms[i].hour24  = 7;
    alarms[i].minute  = 0;
  }
}

static const roos_u32 SETTINGS_MAGIC = 0x524F4F53UL; // "ROOS"
static const roos_u16 SETTINGS_VER   = 1;

// CRC32
static uint32_t crc32_le_update(uint32_t crc, uint8_t data) {
  crc ^= data;
  for (int i = 0; i < 8; i++) crc = (crc >> 1) ^ (0xEDB88320u & (-(int)(crc & 1)));
  return crc;
}
static uint32_t crc32_le(const uint8_t* data, size_t len) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i = 0; i < len; i++) crc = crc32_le_update(crc, data[i]);
  return crc ^ 0xFFFFFFFFu;
}
static uint32_t settingsCrc(const SettingsBlob& b) {
  return crc32_le((const uint8_t*)&b, offsetof(SettingsBlob, crc32));
}

// NVS helpers
static bool nvsReady = false;
static const char* NVS_NS  = "rooster";
static const char* NVS_KEY = "blob";

static bool settingsNvsInit() {
  if (nvsReady) return true;

  esp_err_t err = nvs_flash_init();
  if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
    nvs_flash_erase();
    err = nvs_flash_init();
  }
  if (err != ESP_OK) {
    Serial.printf("NVS init failed: %d\n", (int)err);
    return false;
  }

  nvsReady = true;
  return true;
}

static void settingsLoad() {
  settingsApplyDefaults();
  if (!settingsNvsInit()) return;

  nvs_handle_t h;
  esp_err_t err = nvs_open(NVS_NS, NVS_READONLY, &h);
  if (err != ESP_OK) return;

  SettingsBlob b{};
  size_t len = sizeof(b);
  err = nvs_get_blob(h, NVS_KEY, &b, &len);
  nvs_close(h);

  if (err != ESP_OK || len != sizeof(b)) return;
  if (b.magic != SETTINGS_MAGIC || b.ver != SETTINGS_VER) return;
  if (settingsCrc(b) != b.crc32) return;

  volumeLevel = (int)b.volume;
  if (volumeLevel < VOL_MIN) volumeLevel = VOL_MIN;
  if (volumeLevel > VOL_MAX) volumeLevel = VOL_MAX;

  sensorDistanceHalfFt = (int)b.distHalfFt;
  if (sensorDistanceHalfFt < SENSOR_DIST_MIN_HALF_FT || sensorDistanceHalfFt > SENSOR_DIST_MAX_HALF_FT) sensorDistanceHalfFt = 2;

  sensorTimeHalfMin = (int)b.timeHalfMin;
  if (sensorTimeHalfMin < SENSOR_TIME_MIN_HALF_MIN || sensorTimeHalfMin > SENSOR_TIME_MAX_HALF_MIN) sensorTimeHalfMin = 1;

  for (int i = 0; i < 7; i++) {
    alarms[i].enabled = (b.alarms[i].enabled != 0);
    alarms[i].hour24  = (uint8_t)(b.alarms[i].hour24 % 24);
    alarms[i].minute  = (uint8_t)(b.alarms[i].minute % 60);
  }

  settingsDirty = false;
  rtcAlarmNeedsUpdate = true;
}

static void settingsSaveNow() {
  if (!settingsNvsInit()) { settingsDirty = false; return; }

  SettingsBlob b{};
  b.magic = SETTINGS_MAGIC;
  b.ver   = SETTINGS_VER;

  b.volume      = (roos_u8)volumeLevel;
  b.distHalfFt  = (roos_u8)sensorDistanceHalfFt;
  b.timeHalfMin = (roos_u8)sensorTimeHalfMin;

  for (int i = 0; i < 7; i++) {
    b.alarms[i].enabled = alarms[i].enabled ? 1 : 0;
    b.alarms[i].hour24  = (roos_u8)alarms[i].hour24;
    b.alarms[i].minute  = (roos_u8)alarms[i].minute;
  }

  b.crc32 = settingsCrc(b);

  nvs_handle_t h;
  esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
  if (err != ESP_OK) {
    Serial.printf("NVS open failed: %d\n", (int)err);
    settingsDirty = false;
    return;
  }

  err = nvs_set_blob(h, NVS_KEY, &b, sizeof(b));
  if (err == ESP_OK) err = nvs_commit(h);
  nvs_close(h);

  if (err != ESP_OK) Serial.printf("NVS save failed: %d\n", (int)err);

  settingsDirty = false;
}

static void settingsCommitIfDue() {
  if (!settingsDirty) return;
  uint32_t now = millis();
  if ((uint32_t)(now - settingsDirtySinceMs) >= SETTINGS_COMMIT_DELAY_MS) settingsSaveNow();
}

// ====================== BUTTON / INPUT STATE ======================
const int debounceMs              = 80;
const unsigned long LONG_PRESS_MS = 700;

bool lastModeState   = HIGH;
unsigned long modePressStart = 0;

bool lastUpState     = HIGH;
bool lastDownState   = HIGH;

unsigned long lastUpPressTime     = 0;
unsigned long lastDownPressTime   = 0;

unsigned long upPressStart        = 0;
unsigned long downPressStart      = 0;

unsigned long upLastRepeatTime    = 0;
unsigned long downLastRepeatTime  = 0;

bool upRepeating   = false;
bool downRepeating = false;

const unsigned long REPEAT_START_MS    = 500;
const unsigned long REPEAT_INTERVAL_MS = 120;

// ====================== RTC (RV-3028) LOW-LEVEL I2C ======================
#define RV3028_ADDR 0x52

#define RV3028_REG_SECONDS     0x00
#define RV3028_REG_WEEKDAY     0x03

#define RV3028_REG_MINUTES_ALM 0x07
#define RV3028_REG_HOURS_ALM   0x08
#define RV3028_REG_DAY_ALM     0x09

#define RV3028_REG_STATUS      0x0E
#define RV3028_REG_CTRL1       0x0F
#define RV3028_REG_CTRL2       0x10

#define RV3028_STATUS_AF_MASK   (1u << 2)
#define RV3028_CTRL2_AIE_MASK   (1u << 3)
#define RV3028_CTRL2_12_24_MASK (1u << 1)
#define RV3028_CTRL1_WADA_MASK  (1u << 5)

static uint8_t bcdToDec(uint8_t v) { return (uint8_t)((v >> 4) * 10 + (v & 0x0F)); }
static uint8_t decToBcd(uint8_t v) { return (uint8_t)(((v / 10) << 4) | (v % 10)); }

static void scanI2C() {
  Serial.println("Scanning I2C bus...");
  byte found = 0;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    byte error = Wire.endTransmission();
    if (error == 0) {
      Serial.print("  Found device at 0x");
      if (addr < 16) Serial.print('0');
      Serial.println(addr, HEX);
      found++;
      delay(5);
    }
  }
  if (found == 0) Serial.println("  No I2C devices found");
  else {
    Serial.print("  Done. Devices found: ");
    Serial.println(found);
  }
}

static bool rtcReadReg(uint8_t reg, uint8_t &out) {
  Wire.beginTransmission(RV3028_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)RV3028_ADDR, (uint8_t)1) != 1) return false;
  out = Wire.read();
  return true;
}

static bool rtcWriteReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(RV3028_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return (Wire.endTransmission() == 0);
}

static bool rtcUpdateRegBits(uint8_t reg, uint8_t mask, uint8_t valueMasked) {
  uint8_t cur = 0;
  if (!rtcReadReg(reg, cur)) return false;
  uint8_t next = (uint8_t)((cur & ~mask) | (valueMasked & mask));
  if (next == cur) return true;
  return rtcWriteReg(reg, next);
}

static void rtcEnsure24hMode() {
  rtcUpdateRegBits(RV3028_REG_CTRL2, RV3028_CTRL2_12_24_MASK, 0);
}

static void rtcSelectWeekdayAlarmMode() {
  rtcUpdateRegBits(RV3028_REG_CTRL1, RV3028_CTRL1_WADA_MASK, 0);
}

static void rtcClearAlarmFlag() {
  uint8_t st = 0;
  if (!rtcReadReg(RV3028_REG_STATUS, st)) return;
  st = (uint8_t)(st & ~RV3028_STATUS_AF_MASK);
  rtcWriteReg(RV3028_REG_STATUS, st);
}

static void rtcSetAlarmInterruptEnabled(bool en) {
  rtcUpdateRegBits(RV3028_REG_CTRL2, RV3028_CTRL2_AIE_MASK, en ? RV3028_CTRL2_AIE_MASK : 0);
}

static bool rtcReadRaw(
  uint8_t &sec,
  uint8_t &min,
  uint8_t &hour,
  uint8_t &weekday,
  uint8_t &date,
  uint8_t &month,
  uint8_t &year
) {
  Wire.beginTransmission(RV3028_ADDR);
  Wire.write(0x00);
  if (Wire.endTransmission(false) != 0) return false;

  if (Wire.requestFrom((uint8_t)RV3028_ADDR, (uint8_t)7) != 7) return false;

  sec     = Wire.read();
  min     = Wire.read();
  hour    = Wire.read();
  weekday = Wire.read();
  date    = Wire.read();
  month   = Wire.read();
  year    = Wire.read();
  return true;
}

static void updateTimeFromRTC() {
  static unsigned long lastRtcReadMs = 0;
  unsigned long now = millis();

  if (editMode == EDIT_TIME_HOUR ||
      editMode == EDIT_TIME_MIN  ||
      editMode == EDIT_TIME_AMPM ||
      editMode == EDIT_TIME_DOW) return;

  if (now - lastRtcReadMs < 200) return;
  lastRtcReadMs = now;

  uint8_t sec, min, hour, weekday, date, month, year;
  if (!rtcReadRaw(sec, min, hour, weekday, date, month, year)) return;

  uint8_t newSec  = bcdToDec(sec & 0x7F);
  uint8_t newMin  = bcdToDec(min);
  uint8_t newHour = bcdToDec(hour & 0x3F);
  uint8_t newDow  = (uint8_t)(weekday & 0x07);

  bool changed = (newMin != curMin) || (newHour != curHour) || (newDow != currentDayIndex) || (newSec != curSec);

  curSec  = newSec;
  curMin  = newMin;
  curHour = newHour;
  currentDayIndex = newDow;

  if (changed) needsRedraw = true;
}

static void rtcSetTimeFromUi() {
  uint8_t sec, min, hour, weekday, date, month, year;
  if (!rtcReadRaw(sec, min, hour, weekday, date, month, year)) {
    Serial.println("RTC read failed; not setting time");
    return;
  }

  rtcEnsure24hMode();

  sec     = decToBcd(0);
  min     = decToBcd(curMin);
  hour    = decToBcd(curHour);
  weekday = (uint8_t)(currentDayIndex & 0x07);

  Wire.beginTransmission(RV3028_ADDR);
  Wire.write(0x00);
  Wire.write(sec);
  Wire.write(min);
  Wire.write(hour);
  Wire.write(weekday);
  Wire.write(date);
  Wire.write(month);
  Wire.write(year);
  Wire.endTransmission();

  rtcAlarmNeedsUpdate = true;
  Serial.println("RTC time updated from UI");
}

// ---- compute & program "next" scheduled alarm into RV-3028 alarm regs ----
static int minutesSinceWeekStart(uint8_t dow0Sun, uint8_t hour24, uint8_t minute) {
  return (int)dow0Sun * 1440 + (int)hour24 * 60 + (int)minute;
}

static bool computeNextAlarm(uint8_t nowDow, uint8_t nowHour, uint8_t nowMin,
                             uint8_t &outDow, uint8_t &outHour, uint8_t &outMin) {
  int nowM = minutesSinceWeekStart(nowDow, nowHour, nowMin);

  int bestDelta = 999999;
  bool found = false;

  for (uint8_t d = 0; d < 7; d++) {
    if (!alarms[d].enabled) continue;

    int targetM = minutesSinceWeekStart(d, alarms[d].hour24, alarms[d].minute);

    int delta = targetM - nowM;
    if (delta < 0) delta += 7 * 1440;

    if (delta == 0) delta = 7 * 1440;

    if (delta < bestDelta) {
      bestDelta = delta;
      outDow = d;
      outHour = alarms[d].hour24;
      outMin = alarms[d].minute;
      found = true;
    }
  }

  return found;
}

static void rtcProgramNextAlarm(bool force) {
  uint32_t nowMs = millis();
  if (!force) {
    if (!rtcAlarmNeedsUpdate) return;
    if ((uint32_t)(nowMs - rtcLastProgramMs) < 400) return;
  }

  rtcLastProgramMs = nowMs;
  rtcAlarmNeedsUpdate = false;

  rtcEnsure24hMode();

  uint8_t nextDow=0, nextHour=0, nextMin=0;
  bool have = computeNextAlarm(currentDayIndex, curHour, curMin, nextDow, nextHour, nextMin);

  if (!have) {
    rtcSetAlarmInterruptEnabled(false);
    rtcClearAlarmFlag();
    Serial.println("RTC alarm: none enabled -> AIE=0");
    return;
  }

  rtcSetAlarmInterruptEnabled(false);
  rtcClearAlarmFlag();
  rtcSelectWeekdayAlarmMode();

  rtcWriteReg(RV3028_REG_MINUTES_ALM, decToBcd(nextMin));
  rtcWriteReg(RV3028_REG_HOURS_ALM,   decToBcd(nextHour));
  rtcWriteReg(RV3028_REG_DAY_ALM,     (uint8_t)(nextDow & 0x07));

  rtcClearAlarmFlag();
  rtcSetAlarmInterruptEnabled(true);

  Serial.printf("RTC alarm armed: DOW=%u %02u:%02u (24h)\n",
                (unsigned)nextDow, (unsigned)nextHour, (unsigned)nextMin);
}

// ====================== MELODY CONFIG ======================
struct Note { float freq; float duration; };

const Note melody[] = {
  { 880.0f, 0.25f },
  { 1047.0f, 0.25f },
  { 1319.0f, 0.25f },
  { 1047.0f, 0.25f }
};

const int   NUM_NOTES = sizeof(melody) / sizeof(melody[0]);
const float NOTE_GAP_SEC     = 0.25f;
const float ATTACK_FRACTION  = 0.10f;
const float RELEASE_FRACTION = 0.20f;

double melodyTimeSec  = 0.0;
float  melodyTotalSec = 0.0f;
float  oscPhase       = 0.0f;

// Audio HW state
static bool i2sInstalled   = false;
static bool i2sOk          = false;
static bool audioHwEnabled = false;

// ====================== FLASHING CURSOR STATE ======================
bool flashState = true;
unsigned long lastFlashToggleMs = 0;
const unsigned long FLASH_INTERVAL_MS = 500;

// ====================== SLEEP / WAKE CONFIG ======================
static const uint32_t INACTIVITY_SLEEP_MS = 30000;
static uint32_t lastActivityMs = 0;
static inline void markActivity() { lastActivityMs = millis(); }

static uint64_t wakeMask() {
  return (1ULL << PIN_MODE) | (1ULL << PIN_VOL_UP) | (1ULL << PIN_VOL_DOWN) | (1ULL << PIN_RTC_INT);
}

static void printPinRtcInfo(const char* name, int pin) {
  bool valid = rtc_gpio_is_valid_gpio((gpio_num_t)pin);
  Serial.printf("RTC wake pin check: %s GPIO%d => %s\n", name, pin, valid ? "OK (RTC-capable)" : "NOT RTC-capable");
}

static bool wokeFromRtcInt = false;

static void printWakeReason() {
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
  wokeFromRtcInt = false;

  if (cause == ESP_SLEEP_WAKEUP_EXT1) {
    uint64_t status = esp_sleep_get_ext1_wakeup_status();
    if (status & (1ULL << PIN_MODE))     Serial.println("Wake: MODE");
    if (status & (1ULL << PIN_VOL_UP))   Serial.println("Wake: UP");
    if (status & (1ULL << PIN_VOL_DOWN)) Serial.println("Wake: DOWN");
    if (status & (1ULL << PIN_RTC_INT))  { Serial.println("Wake: RTC_INT"); wokeFromRtcInt = true; }
  } else {
    Serial.printf("Wake cause: %d\n", (int)cause);
  }
}

// ====================== SESSIONS ======================
static SessionKind activeSession = SESSION_NONE;
static bool        sessionWaitingAck = false;
static bool        sessionSoundOn    = false;
static uint32_t    sessionSeq        = 0;
static uint32_t    sessionAckDeadlineMs = 0;
static const uint32_t SESSION_ACK_TIMEOUT_MS = 1200;

// Test UI only:
static TestStatus testStatus = TEST_STATUS_NONE;
static uint32_t   testStatusSetMs = 0;
static const uint32_t TEST_STATUS_SHOW_MS = 5000;

// Presence bookkeeping
static bool everHadPresenceThisSession = false;
static bool lastBeaconPresentThisSession = false;

static inline bool sessionActive()   { return activeSession != SESSION_NONE; }
static inline bool audioShouldRun()  { return sessionActive() && sessionSoundOn; }

static void setTestStatus(TestStatus s) {
  testStatus = s;
  testStatusSetMs = millis();
  needsRedraw = true;
}

// ====================== SAFE RX FLAGS (no I2S transitions in callback) ======================
static portMUX_TYPE rxMux = portMUX_INITIALIZER_UNLOCKED;

static volatile bool rxAckPending      = false;
static volatile uint32_t rxAckSeq      = 0;
static volatile uint8_t  rxAckOk       = 0;

static volatile bool rxPresencePending = false;
static volatile uint32_t rxPresenceSeq = 0;
static volatile uint8_t  rxPresent     = 0;
static volatile uint16_t rxDistCm      = 0;

static volatile bool rxSuccessPending  = false;
static volatile uint32_t rxSuccessSeq  = 0;

// ====================== I2S INSTALL/UNINSTALL ======================
static void setI2SPinsHiZ() {
  pinMode(GPIO_I2S_BCLK,  INPUT);
  pinMode(GPIO_I2S_LRCLK, INPUT);
  pinMode(GPIO_I2S_DATA,  INPUT);
}

static bool installI2S() {
  if (i2sInstalled) return true;

  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 256,
    .use_apll = false,
    .tx_desc_auto_clear = true,
    .fixed_mclk = 0
  };

  if (i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL) != ESP_OK) return false;

  i2s_pin_config_t pin_config = {
    .bck_io_num   = GPIO_I2S_BCLK,
    .ws_io_num    = GPIO_I2S_LRCLK,
    .data_out_num = GPIO_I2S_DATA,
    .data_in_num  = I2S_PIN_NO_CHANGE
  };

  if (i2s_set_pin(I2S_PORT, &pin_config) != ESP_OK) return false;

  if (i2s_set_clk(I2S_PORT, SAMPLE_RATE,
                  I2S_BITS_PER_SAMPLE_16BIT,
                  I2S_CHANNEL_STEREO) != ESP_OK) return false;

  i2sInstalled = true;
  return true;
}

static void uninstallI2S() {
  if (!i2sInstalled) {
    setI2SPinsHiZ();
    return;
  }

  i2s_zero_dma_buffer(I2S_PORT);
  i2s_stop(I2S_PORT);
  i2s_driver_uninstall(I2S_PORT);
  i2sInstalled = false;

  setI2SPinsHiZ();
}

// ====================== AUDIO HW GATE (TRANSITION ONLY) ======================
static void audioHwEnable() {
  if (audioHwEnabled) return;

  if (!installI2S()) {
    Serial.println("I2S install failed");
    return;
  }

  audioMute(true);

  i2s_zero_dma_buffer(I2S_PORT);
  i2s_start(I2S_PORT);

  static int16_t zeros[256 * 2] = {0};
  size_t bw;
  for (int i = 0; i < 6; i++) {
    i2s_write(I2S_PORT, (const char*)zeros, sizeof(zeros), &bw, portMAX_DELAY);
  }

  audioMute(false);
  audioHwEnabled = true;
}

static void audioHwDisable() {
  if (!audioHwEnabled) {
    uninstallI2S();
    return;
  }

  audioMute(true);
  uninstallI2S();
  audioHwEnabled = false;
}

static void ensureAudioHw(bool wantOn) {
  if (wantOn) audioHwEnable();
  else        audioHwDisable();
}

// ====================== ESPNOW SEND HELPERS ======================
static void sendBeaconConfig(const char* reason, uint32_t seqToSend) {
  if (!espNowOk) {
    Serial.println("ESP-NOW not ready; cannot send config");
    return;
  }

  BeaconCfgMsg msg{};
  memcpy(msg.magic, MAGIC_ROOS, 4);
  msg.version     = (roos_u8)PROTO_VER;
  msg.msgType     = (roos_u8)MSG_CONFIG;
  msg.distHalfFt  = (roos_u8)sensorDistanceHalfFt;
  msg.timeHalfMin = (roos_u8)sensorTimeHalfMin;
  msg.seq         = (roos_u32)seqToSend;

  esp_err_t err = esp_now_send(BEACON_MAC, (uint8_t*)&msg, sizeof(msg));
  Serial.printf("ESP-NOW send cfg (%s): distHalfFt=%u timeHalfMin=%u seq=%u err=%d\n",
                reason,
                (unsigned)msg.distHalfFt,
                (unsigned)msg.timeHalfMin,
                (unsigned)msg.seq,
                (int)err);
}

static void sendBeaconStop(uint32_t seqToStop, const char* why) {
  if (!espNowOk || seqToStop == 0) return;

  BeaconStopMsg st{};
  memcpy(st.magic, MAGIC_ROOS, 4);
  st.version = (roos_u8)PROTO_VER;
  st.msgType = (roos_u8)MSG_STOP;
  st.seq     = (roos_u32)seqToStop;

  esp_err_t err = esp_now_send(BEACON_MAC, (uint8_t*)&st, sizeof(st));
  Serial.printf("ESP-NOW send STOP (%s): seq=%u err=%d\n",
                why, (unsigned)seqToStop, (int)err);
}

// ====================== SESSION CONTROL ======================
static void endSessionInternal(const char* why, bool sendStop) {
  markActivity();

  const uint32_t oldSeq = sessionSeq;
  const SessionKind oldKind = activeSession;

  // Stop Beacon session first (before we clear seq)
  if (sendStop && oldKind != SESSION_NONE && oldSeq != 0) {
    sendBeaconStop(oldSeq, why);
  }

  activeSession = SESSION_NONE;
  sessionWaitingAck = false;
  sessionSoundOn = false;
  sessionSeq = 0;
  sessionAckDeadlineMs = 0;

  everHadPresenceThisSession = false;
  lastBeaconPresentThisSession = false;

  ensureAudioHw(false);
  rtcAlarmNeedsUpdate = true;
  needsRedraw = true;
}

static void endSession() {
  endSessionInternal("endSession", true);
}

static void startSession(SessionKind kind, const char* reason) {
  markActivity();

  activeSession = kind;
  sessionSoundOn = true;

  everHadPresenceThisSession = false;
  lastBeaconPresentThisSession = false;

  melodyTimeSec = 0.0;
  oscPhase = 0.0f;

  if (!espNowOk) {
    if (kind == SESSION_TEST) {
      sessionWaitingAck = false;
      sessionSeq = 0;
      sessionAckDeadlineMs = 0;
      setTestStatus(TEST_STATUS_AUDIO_ONLY);
      ensureAudioHw(true);
      needsRedraw = true;
      Serial.println("TEST session: ESP-NOW not ready -> audio-only test");
      return;
    } else {
      endSessionInternal("espnow_not_ready", false);
      return;
    }
  }

  sessionWaitingAck = true;
  sessionSeq = ++cfgSeq;
  sessionAckDeadlineMs = millis() + SESSION_ACK_TIMEOUT_MS;

  if (kind == SESSION_TEST) setTestStatus(TEST_STATUS_NONE);

  ensureAudioHw(true);
  sendBeaconConfig(reason, sessionSeq);

  Serial.printf("SESSION START kind=%u seq=%u waiting ACK...\n", (unsigned)kind, (unsigned)sessionSeq);
  needsRedraw = true;
}

static void updateSession() {
  if (!sessionActive()) return;

  if (sessionWaitingAck && (int32_t)(millis() - sessionAckDeadlineMs) >= 0) {
    Serial.printf("SESSION: ACK TIMEOUT seq=%u\n", (unsigned)sessionSeq);
    if (activeSession == SESSION_TEST) setTestStatus(TEST_STATUS_ERROR);
    endSessionInternal("ack_timeout", true);
  }
}

// ====================== TEST SESSION UI HOOKS ======================
static inline bool testIsRunning() { return activeSession == SESSION_TEST; }

static inline const char* testStatusToText(TestStatus s) {
  switch (s) {
    case TEST_STATUS_ERROR:             return "Error reaching beacon";
    case TEST_STATUS_PRESENCE_DETECTED: return "Human Presence Detected";
    case TEST_STATUS_PRESENCE_LOST:     return "Human Presence Lost";
    case TEST_STATUS_SUCCESS:           return "Success";
    case TEST_STATUS_AUDIO_ONLY:        return "Audio test (no beacon)";
    default:                            return "";
  }
}

static void startTestSession() { startSession(SESSION_TEST, "test_start"); }

static void stopTestSessionManual() {
  setTestStatus(TEST_STATUS_NONE);
  endSessionInternal("test_manual_stop", true);
}

// ====================== SCHEDULED ALARM SESSION ======================
static void startAlarmSessionScheduled() { startSession(SESSION_ALARM, "alarm_start"); }

static inline bool timeScreenEditing() {
  return (currentScreen == SCREEN_TIME) &&
         (editMode == EDIT_TIME_HOUR ||
          editMode == EDIT_TIME_MIN  ||
          editMode == EDIT_TIME_AMPM ||
          editMode == EDIT_TIME_DOW);
}

static void updateScheduledAlarmTrigger() {
  if (sessionActive()) return;
  if (timeScreenEditing()) return;

  DayAlarm &da = alarms[currentDayIndex];
  if (!da.enabled) return;

  int key = makeAlarmTriggerKey();
  if (curHour == da.hour24 && curMin == da.minute && key != lastAlarmTriggerKey) {
    lastAlarmTriggerKey = key;
    startAlarmSessionScheduled();
  }
}

// ====================== ESPNOW CALLBACKS (ONLY SET FLAGS) ======================
static void onEspNowSent(const wifi_tx_info_t *info, esp_now_send_status_t status) {
  if (info && info->des_addr) {
    Serial.printf("ESP-NOW send to %02X:%02X:%02X:%02X:%02X:%02X => %s\n",
      info->des_addr[0], info->des_addr[1], info->des_addr[2],
      info->des_addr[3], info->des_addr[4], info->des_addr[5],
      status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
  } else {
    Serial.printf("ESP-NOW send => %s\n", status == ESP_NOW_SEND_SUCCESS ? "SUCCESS" : "FAIL");
  }
}

static void onEspNowRecv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  (void)info;

  if (len < 6) return;
  if (memcmp(data, MAGIC_ROOS, 4) != 0) return;
  if (data[4] != PROTO_VER) return;

  const uint8_t type = data[5];

  if (type == MSG_ACK) {
    if (len != (int)sizeof(BeaconAckMsg)) return;
    BeaconAckMsg m{};
    memcpy(&m, data, sizeof(m));

    portENTER_CRITICAL(&rxMux);
    rxAckPending = true;
    rxAckSeq = (uint32_t)m.seq;
    rxAckOk  = (uint8_t)m.ok;
    portEXIT_CRITICAL(&rxMux);
  }
  else if (type == MSG_PRESENCE) {
    if (len != (int)sizeof(BeaconPresenceMsg)) return;
    BeaconPresenceMsg m{};
    memcpy(&m, data, sizeof(m));

    portENTER_CRITICAL(&rxMux);
    rxPresencePending = true;
    rxPresenceSeq = (uint32_t)m.seq;
    rxPresent     = (uint8_t)m.present;
    rxDistCm      = (uint16_t)m.distCm;
    portEXIT_CRITICAL(&rxMux);
  }
  else if (type == MSG_SUCCESS) {
    if (len != (int)sizeof(BeaconSuccessMsg)) return;
    BeaconSuccessMsg m{};
    memcpy(&m, data, sizeof(m));

    portENTER_CRITICAL(&rxMux);
    rxSuccessPending = true;
    rxSuccessSeq = (uint32_t)m.seq;
    portEXIT_CRITICAL(&rxMux);
  }
}

// Called from loop(): apply rx flags safely
static void processRxEvents() {
  bool doAck=false, doPresence=false, doSuccess=false;
  uint32_t ackSeq=0, presSeq=0, sucSeq=0;
  uint8_t  ackOk=0, present=0;
  uint16_t distCm=0;

  portENTER_CRITICAL(&rxMux);
  if (rxAckPending) {
    rxAckPending = false;
    doAck = true; ackSeq = rxAckSeq; ackOk = rxAckOk;
  }
  if (rxPresencePending) {
    rxPresencePending = false;
    doPresence = true; presSeq = rxPresenceSeq; present = rxPresent; distCm = rxDistCm;
  }
  if (rxSuccessPending) {
    rxSuccessPending = false;
    doSuccess = true; sucSeq = rxSuccessSeq;
  }
  portEXIT_CRITICAL(&rxMux);

  if (doAck) {
    Serial.printf("RX ACK seq=%u ok=%u\n", (unsigned)ackSeq, (unsigned)ackOk);
    if (sessionActive() && sessionWaitingAck && ackSeq == sessionSeq) {
      if (ackOk == 1) sessionWaitingAck = false;
      else {
        if (activeSession == SESSION_TEST) setTestStatus(TEST_STATUS_ERROR);
        endSessionInternal("ack_rejected", true);
      }
    }
  }

  if (doPresence) {
    Serial.printf("RX PRESENCE present=%u seq=%u distCm=%u\n",
                  (unsigned)present, (unsigned)presSeq, (unsigned)distCm);

    if (sessionActive() && presSeq == sessionSeq) {
      const bool presentNow = (present != 0);

      if (presentNow) {
        if (!lastBeaconPresentThisSession) {
          everHadPresenceThisSession = true;
          if (activeSession == SESSION_TEST) setTestStatus(TEST_STATUS_PRESENCE_DETECTED);
        }
        sessionSoundOn = false;
        lastBeaconPresentThisSession = true;
      } else {
        if (everHadPresenceThisSession && lastBeaconPresentThisSession) {
          sessionSoundOn = true;
          if (activeSession == SESSION_TEST) setTestStatus(TEST_STATUS_PRESENCE_LOST);
          lastBeaconPresentThisSession = false;
        } else {
          lastBeaconPresentThisSession = false;
        }
      }

      needsRedraw = true;
    }
  }

  if (doSuccess) {
    Serial.printf("RX SUCCESS seq=%u\n", (unsigned)sucSeq);
    if (sessionActive() && sucSeq == sessionSeq) {
      if (activeSession == SESSION_TEST) setTestStatus(TEST_STATUS_SUCCESS);
      endSessionInternal("success", true);
    }
  }
}

// ====================== ESPNOW SETUP ======================
static bool setupEspNow() {
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);

  esp_wifi_set_ps(WIFI_PS_NONE);

  // Reduce TX power to limit RF coupling into audio (units are 0.25 dBm).
  esp_wifi_set_max_tx_power(40);

  WiFi.disconnect(false, true);
  delay(100);

  esp_err_t s = esp_wifi_start();
  Serial.printf("esp_wifi_start => %d\n", (int)s);

  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(ESPNOW_CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_promiscuous(false);

  if (esp_now_init() != ESP_OK) return false;

  esp_now_register_send_cb(onEspNowSent);
  esp_now_register_recv_cb(onEspNowRecv);

  esp_now_peer_info_t peer{};
  memcpy(peer.peer_addr, BEACON_MAC, 6);
  peer.channel = ESPNOW_CHANNEL;
  peer.encrypt = false;

  if (!esp_now_is_peer_exist(BEACON_MAC)) {
    if (esp_now_add_peer(&peer) != ESP_OK) return false;
  }
  return true;
}

// ====================== UTILS: MELODY ======================
static float computeMelodyTotalDuration() {
  float total = 0.0f;
  for (int i = 0; i < NUM_NOTES; i++) total += melody[i].duration + NOTE_GAP_SEC;
  return total;
}

static float noteEnvelope(float t, float noteDuration) {
  if (t < 0.0f || t > noteDuration) return 0.0f;

  float attack  = ATTACK_FRACTION  * noteDuration;
  float release = RELEASE_FRACTION * noteDuration;

  if (attack < 0.001f) attack = 0.001f;
  if (release < 0.001f) release = 0.001f;
  if (attack + release > noteDuration) {
    float scale = noteDuration / (attack + release);
    attack  *= scale;
    release *= scale;
  }

  if (t < attack) return t / attack;
  if (t > noteDuration - release) return (noteDuration - t) / release;
  return 1.0f;
}

static float getMelodySample() {
  if (melodyTotalSec <= 0.0f) return 0.0f;

  float tCycle = fmodf((float)melodyTimeSec, melodyTotalSec);

  float cursor = 0.0f;
  for (int i = 0; i < NUM_NOTES; i++) {
    float segment = melody[i].duration + NOTE_GAP_SEC;

    if (tCycle < cursor + segment) {
      float local = tCycle - cursor;

      if (local > melody[i].duration) return 0.0f;

      float env  = noteEnvelope(local, melody[i].duration);
      float freq = melody[i].freq;

      float phaseInc = (float)(TWO_PI * freq / (float)SAMPLE_RATE);
      oscPhase += phaseInc;
      if (oscPhase >= TWO_PI) oscPhase -= TWO_PI;

      float s1 = sinf(oscPhase);
      float s2 = sinf(2.0f * oscPhase);
      float mixed = 0.9f * s1 + 0.1f * s2;

      return env * mixed;
    }
    cursor += segment;
  }

  return 0.0f;
}

// ====================== 12H HELPERS ======================
static void getTime12(uint8_t hour24, uint8_t &outHour12, bool &outIsPm) {
  if (hour24 == 0)      { outHour12 = 12; outIsPm = false; }
  else if (hour24 < 12) { outHour12 = hour24; outIsPm = false; }
  else if (hour24 == 12){ outHour12 = 12; outIsPm = true; }
  else                  { outHour12 = hour24 - 12; outIsPm = true; }
}

static void toggleTimeAmPm(uint8_t &hour24) { hour24 = (hour24 + 12) % 24; }

static void incrementCurrentHour()   { curHour = (curHour + 1) % 24; }
static void decrementCurrentHour()   { curHour = (curHour + 23) % 24; }
static void incrementCurrentMinute() { curMin = (curMin + 1) % 60; }
static void decrementCurrentMinute() { curMin = (curMin + 59) % 60; }

static void incrementAlarmHour(uint8_t day)   { alarms[day].hour24 = (alarms[day].hour24 + 1) % 24; }
static void decrementAlarmHour(uint8_t day)   { alarms[day].hour24 = (alarms[day].hour24 + 23) % 24; }
static void incrementAlarmMinute(uint8_t day) { alarms[day].minute = (alarms[day].minute + 1) % 60; }
static void decrementAlarmMinute(uint8_t day) { alarms[day].minute = (alarms[day].minute + 59) % 60; }

// ====================== FLASHING ======================
static void updateFlashState() {
  if (editMode == EDIT_NONE) { flashState = true; return; }
  unsigned long now = millis();
  if (now - lastFlashToggleMs >= FLASH_INTERVAL_MS) {
    lastFlashToggleMs = now;
    flashState = !flashState;
    needsRedraw = true;
  }
}

// ====================== OLED DRAW HELPERS ======================
static const int TITLE_Y = 24;
static const int VALUE_Y = 44;
static const int DOW_Y   = 60;
static const char dayChars[7] = { 'S','M','T','W','T','F','S' };

static void drawTimeLikeValue(uint8_t hour24, uint8_t minute,
                       bool showAmPm,
                       bool selHour, bool selMin, bool selAmPm) {
  uint8_t h12; bool isPm;
  getTime12(hour24, h12, isPm);

  char hh[3], mm[3], ampm[3];
  snprintf(hh, sizeof(hh), "%02u", (unsigned)h12);
  snprintf(mm, sizeof(mm), "%02u", (unsigned)minute);
  snprintf(ampm, sizeof(ampm), "%s", isPm ? "PM" : "AM");

  u8g2.setFont(u8g2_font_9x18B_tr);

  int wHH    = u8g2.getStrWidth(hh);
  int wColon = u8g2.getStrWidth(":");
  int wMM    = u8g2.getStrWidth(mm);
  int wSpace = u8g2.getStrWidth(" ");
  int wAMPM  = showAmPm ? u8g2.getStrWidth(ampm) : 0;

  int totalWidth = wHH + wColon + wMM + (showAmPm ? (wSpace + wAMPM) : 0);
  int x = (128 - totalWidth) / 2;

  if (!(selHour && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(hh); }
  x += wHH;

  u8g2.setCursor(x, VALUE_Y); u8g2.print(":");
  x += wColon;

  if (!(selMin && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(mm); }
  x += wMM;

  if (showAmPm) {
    u8g2.setCursor(x, VALUE_Y); u8g2.print(" ");
    x += wSpace;

    if (!(selAmPm && !flashState)) { u8g2.setCursor(x, VALUE_Y); u8g2.print(ampm); }
  }
}

static void drawDowRowTime() {
  u8g2.setFont(u8g2_font_6x12_tr);
  int cellWidth = 128 / 7;
  int boxHeight = 10;
  int boxY      = DOW_Y - boxHeight + 1;

  for (int i = 0; i < 7; i++) {
    bool isSelectedDay = (i == currentDayIndex);
    bool inEdit        = (editMode == EDIT_TIME_DOW);

    char c[2] = { dayChars[i], '\0' };
    int w = u8g2.getStrWidth(c);
    int x = i * cellWidth + (cellWidth - w) / 2;

    bool skip = (isSelectedDay && inEdit && !flashState);

    if (!skip) { u8g2.setCursor(x, DOW_Y); u8g2.print(c); }

    if (isSelectedDay) {
      u8g2.setDrawColor(1);
      u8g2.drawFrame(x - 2, boxY - 1, w + 4, boxHeight + 2);
    }
  }
}

static void drawDowRowAlarm() {
  u8g2.setFont(u8g2_font_6x12_tr);
  int cellWidth = 128 / 7;
  int boxHeight = 10;
  int boxY      = DOW_Y - boxHeight + 1;

  for (int i = 0; i < 7; i++) {
    bool isCursor    = (i == alarmDayCursor);
    bool isEnabled   = alarms[i].enabled;
    bool isEnableSel = (editMode == EDIT_ALARM_ENABLE && isCursor);

    char c[2] = { dayChars[i], '\0' };
    int w = u8g2.getStrWidth(c);
    int x = i * cellWidth + (cellWidth - w) / 2;

    bool skipLetter = (isEnableSel && !flashState);

    if (isEnabled) {
      u8g2.setDrawColor(1);
      u8g2.drawBox(x - 1, boxY, w + 2, boxHeight);
      u8g2.setDrawColor(0);
      if (!skipLetter) { u8g2.setCursor(x, DOW_Y); u8g2.print(c); }
      u8g2.setDrawColor(1);
    } else {
      if (!skipLetter) { u8g2.setCursor(x, DOW_Y); u8g2.print(c); }
    }

    if (isCursor) {
      u8g2.setDrawColor(1);
      u8g2.drawFrame(x - 2, boxY - 1, w + 4, boxHeight + 2);
    }
  }
}

static void drawCenteredSmallTextWrapped(const char* txt) {
  if (!txt || txt[0] == '\0') return;

  u8g2.setFont(u8g2_font_5x8_tr);

  int w = u8g2.getStrWidth(txt);
  if (w <= 128) {
    int x = (128 - w) / 2;
    u8g2.setCursor(x, 62);
    u8g2.print(txt);
    return;
  }

  const int n = (int)strlen(txt);
  int mid = n / 2;
  int split = -1;
  for (int i = 0; i < n; i++) {
    int idx = (mid + i < n) ? (mid + i) : -1;
    if (idx >= 0 && txt[idx] == ' ') { split = idx; break; }
    idx = (mid - i >= 0) ? (mid - i) : -1;
    if (idx >= 0 && txt[idx] == ' ') { split = idx; break; }
  }
  if (split < 0) split = mid;

  char line1[64]; char line2[64];
  int l1 = min(split, (int)sizeof(line1) - 1);
  memcpy(line1, txt, l1);
  line1[l1] = '\0';

  int start2 = split;
  while (start2 < n && txt[start2] == ' ') start2++;

  int l2 = min(n - start2, (int)sizeof(line2) - 1);
  memcpy(line2, txt + start2, l2);
  line2[l2] = '\0';

  int w1 = u8g2.getStrWidth(line1);
  int w2 = u8g2.getStrWidth(line2);

  u8g2.setCursor((128 - w1) / 2, 56);
  u8g2.print(line1);

  u8g2.setCursor((128 - w2) / 2, 64);
  u8g2.print(line2);
}

// ====================== DISPLAY ======================
static void updateDisplay() {
  u8g2.clearBuffer();

  const char* title = "";
  switch (currentScreen) {
    case SCREEN_TIME:         title = "Time";                  break;
    case SCREEN_ALARM:        title = "Alarm";                 break;
    case SCREEN_VOLUME:       title = "Volume";                break;
    case SCREEN_SENSOR_TIME:  title = "Sensor Time (Min)";     break;
    case SCREEN_SENSOR_DIST:  title = "Sensor Distance (Max)"; break;
    case SCREEN_TEST:         title = "Test";                  break;
  }

  u8g2.setFont(u8g2_font_6x12_tr);
  {
    int titleWidth = u8g2.getStrWidth(title);
    u8g2.setCursor((128 - titleWidth) / 2, TITLE_Y);
    u8g2.print(title);
  }

  if (currentScreen == SCREEN_VOLUME) {
    char buf[16];
    snprintf(buf, sizeof(buf), "%d/%d", volumeLevel, VOL_MAX);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_TIME) {
    bool selHour  = (editMode == EDIT_TIME_HOUR);
    bool selMin   = (editMode == EDIT_TIME_MIN);
    bool selAmPm  = (editMode == EDIT_TIME_AMPM);

    drawTimeLikeValue(curHour, curMin, true, selHour, selMin, selAmPm);
    drawDowRowTime();
  }
  else if (currentScreen == SCREEN_ALARM) {
    DayAlarm &da = alarms[alarmDayCursor];
    bool selHour  = (editMode == EDIT_ALARM_HOUR);
    bool selMin   = (editMode == EDIT_ALARM_MIN);
    bool selAmPm  = (editMode == EDIT_ALARM_AMPM);

    drawTimeLikeValue(da.hour24, da.minute, true, selHour, selMin, selAmPm);
    drawDowRowAlarm();
  }
  else if (currentScreen == SCREEN_SENSOR_DIST) {
    char buf[16];
    formatHalfFt(buf, sizeof(buf), sensorDistanceHalfFt);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_SENSOR_TIME) {
    char buf[16];
    formatHalfMin(buf, sizeof(buf), sensorTimeHalfMin);
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);
  }
  else if (currentScreen == SCREEN_TEST) {
    const char* buf = testIsRunning() ? "Stop" : "Start";
    u8g2.setFont(u8g2_font_9x18B_tr);
    int w = u8g2.getStrWidth(buf);
    u8g2.setCursor((128 - w) / 2, VALUE_Y);
    u8g2.print(buf);

    const bool showStatus = (testStatus != TEST_STATUS_NONE) &&
                            ((uint32_t)(millis() - testStatusSetMs) <= TEST_STATUS_SHOW_MS);

    if (showStatus) drawCenteredSmallTextWrapped(testStatusToText(testStatus));
  }

  u8g2.sendBuffer();
}

// ====================== SLEEP HELPERS ======================
static void shutdownPeripheralsForSleep() {
  u8g2.setPowerSave(1);
  ensureAudioHw(false);
}

static void waitForButtonsReleased() {
  if (digitalRead(PIN_MODE) == LOW || digitalRead(PIN_VOL_UP) == LOW || digitalRead(PIN_VOL_DOWN) == LOW) {
    Serial.println("Sleep blocked: button held. Waiting for release...");
    while (digitalRead(PIN_MODE) == LOW || digitalRead(PIN_VOL_UP) == LOW || digitalRead(PIN_VOL_DOWN) == LOW) {
      delay(10);
    }
    delay(50);
  }
}

static void enableRtcPullupsIfPossible(gpio_num_t pin) {
  if (!rtc_gpio_is_valid_gpio(pin)) return;
  rtc_gpio_deinit(pin);
  rtc_gpio_pullup_en(pin);
  rtc_gpio_pulldown_dis(pin);
}

static void goToDeepSleep() {
  waitForButtonsReleased();

  if (settingsDirty) settingsSaveNow();

  rtcProgramNextAlarm(true);

  shutdownPeripheralsForSleep();

  pinMode(PIN_VOL_UP,   INPUT_PULLUP);
  pinMode(PIN_VOL_DOWN, INPUT_PULLUP);
  pinMode(PIN_MODE,     INPUT_PULLUP);
  pinMode(PIN_RTC_INT,  INPUT_PULLUP);

  enableRtcPullupsIfPossible((gpio_num_t)PIN_MODE);
  enableRtcPullupsIfPossible((gpio_num_t)PIN_VOL_UP);
  enableRtcPullupsIfPossible((gpio_num_t)PIN_VOL_DOWN);
  enableRtcPullupsIfPossible((gpio_num_t)PIN_RTC_INT);

  esp_sleep_enable_ext1_wakeup(wakeMask(), ESP_EXT1_WAKEUP_ANY_LOW);

  Serial.println("Entering deep sleep...");
  delay(50);
  esp_deep_sleep_start();
}

// ====================== BUTTON HANDLERS ======================
static void handleModeShortPress() {
  markActivity();

  if (currentScreen == SCREEN_TEST && testIsRunning()) {
    stopTestSessionManual();
    needsRedraw = true;
    return;
  }

  if (editMode == EDIT_NONE) {
    UiScreen next = (UiScreen)((currentScreen + 1) % NUM_SCREENS);
    if (next == SCREEN_ALARM) alarmDayCursor = currentDayIndex;
    currentScreen = next;
  } else {
    switch (editMode) {
      case EDIT_TIME_HOUR: editMode = EDIT_TIME_MIN;  break;
      case EDIT_TIME_MIN:  editMode = EDIT_TIME_AMPM; break;
      case EDIT_TIME_AMPM: editMode = EDIT_TIME_DOW;  break;
      case EDIT_TIME_DOW:
        rtcSetTimeFromUi();
        editMode = EDIT_NONE;
        break;

      case EDIT_ALARM_HOUR:   editMode = EDIT_ALARM_MIN;    break;
      case EDIT_ALARM_MIN:    editMode = EDIT_ALARM_AMPM;   break;
      case EDIT_ALARM_AMPM:   editMode = EDIT_ALARM_ENABLE; break;
      case EDIT_ALARM_ENABLE: editMode = EDIT_NONE;         break;

      case EDIT_SENSOR_DIST:  editMode = EDIT_NONE;         break;
      case EDIT_SENSOR_TIME:  editMode = EDIT_NONE;         break;

      default: editMode = EDIT_NONE; break;
    }
  }

  needsRedraw = true;
}

static void handleModeLongPress() {
  markActivity();

  if (editMode != EDIT_NONE) {
    editMode = EDIT_NONE;
  } else {
    switch (currentScreen) {
      case SCREEN_TIME:        editMode = EDIT_TIME_HOUR;    break;
      case SCREEN_ALARM:       editMode = EDIT_ALARM_HOUR;   break;
      case SCREEN_SENSOR_DIST: editMode = EDIT_SENSOR_DIST;  break;
      case SCREEN_SENSOR_TIME: editMode = EDIT_SENSOR_TIME;  break;
      default: break;
    }
  }
  needsRedraw = true;
}

static void handleTestToggleStartStop() {
  if (testIsRunning()) stopTestSessionManual();
  else startTestSession();
}

static void handleUpShortPress() {
  bool changed = false;

  switch (editMode) {
    case EDIT_NONE:
      if (currentScreen == SCREEN_TEST) { handleTestToggleStartStop(); return; }

      switch (currentScreen) {
        case SCREEN_VOLUME:
          if (volumeLevel < VOL_MAX) { volumeLevel++; changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_SENSOR_DIST:
          if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_SENSOR_TIME:
          if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_ALARM:
          alarmDayCursor = (alarmDayCursor + 1) % 7;
          changed = true;
          break;
        default: break;
      }
      break;

    case EDIT_TIME_HOUR: incrementCurrentHour();   changed = true; break;
    case EDIT_TIME_MIN:  incrementCurrentMinute(); changed = true; break;
    case EDIT_TIME_AMPM: toggleTimeAmPm(curHour);  changed = true; break;
    case EDIT_TIME_DOW:  currentDayIndex = (currentDayIndex + 1) % 7; changed = true; rtcAlarmNeedsUpdate = true; break;

    case EDIT_ALARM_HOUR:   incrementAlarmHour(alarmDayCursor);   changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_MIN:    incrementAlarmMinute(alarmDayCursor); changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_AMPM:   toggleTimeAmPm(alarms[alarmDayCursor].hour24); changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_ENABLE: alarms[alarmDayCursor].enabled = !alarms[alarmDayCursor].enabled; changed = true; settingsMarkDirty(); break;

    case EDIT_SENSOR_DIST:
      if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_SENSOR_TIME:
      if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    default: break;
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void handleDownShortPress() {
  bool changed = false;

  switch (editMode) {
    case EDIT_NONE:
      if (currentScreen == SCREEN_TEST) { handleTestToggleStartStop(); return; }

      switch (currentScreen) {
        case SCREEN_VOLUME:
          if (volumeLevel > VOL_MIN) { volumeLevel--; changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_SENSOR_DIST:
          if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_SENSOR_TIME:
          if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; settingsMarkDirty(); }
          break;
        case SCREEN_ALARM:
          alarmDayCursor = (alarmDayCursor + 6) % 7;
          changed = true;
          break;
        default: break;
      }
      break;

    case EDIT_TIME_HOUR: decrementCurrentHour();   changed = true; break;
    case EDIT_TIME_MIN:  decrementCurrentMinute(); changed = true; break;
    case EDIT_TIME_AMPM: toggleTimeAmPm(curHour);  changed = true; break;
    case EDIT_TIME_DOW:  currentDayIndex = (currentDayIndex + 6) % 7; changed = true; rtcAlarmNeedsUpdate = true; break;

    case EDIT_ALARM_HOUR:   decrementAlarmHour(alarmDayCursor);   changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_MIN:    decrementAlarmMinute(alarmDayCursor); changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_AMPM:   toggleTimeAmPm(alarms[alarmDayCursor].hour24); changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_ENABLE: alarms[alarmDayCursor].enabled = !alarms[alarmDayCursor].enabled; changed = true; settingsMarkDirty(); break;

    case EDIT_SENSOR_DIST:
      if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_SENSOR_TIME:
      if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    default: break;
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void handleUpRepeat() {
  bool changed = false;

  switch (editMode) {
    case EDIT_NONE:
      if (currentScreen == SCREEN_VOLUME && volumeLevel < VOL_MAX) { volumeLevel++; changed = true; settingsMarkDirty(); }
      if (currentScreen == SCREEN_SENSOR_DIST && sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; settingsMarkDirty(); }
      if (currentScreen == SCREEN_SENSOR_TIME && sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_TIME_HOUR: incrementCurrentHour();   changed = true; break;
    case EDIT_TIME_MIN:  incrementCurrentMinute(); changed = true; break;

    case EDIT_ALARM_HOUR: incrementAlarmHour(alarmDayCursor);   changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_MIN:  incrementAlarmMinute(alarmDayCursor); changed = true; settingsMarkDirty(); break;

    case EDIT_SENSOR_DIST:
      if (sensorDistanceHalfFt < SENSOR_DIST_MAX_HALF_FT) { incSensorDist(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_SENSOR_TIME:
      if (sensorTimeHalfMin < SENSOR_TIME_MAX_HALF_MIN) { incSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    default: break;
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void handleDownRepeat() {
  bool changed = false;

  switch (editMode) {
    case EDIT_NONE:
      if (currentScreen == SCREEN_VOLUME && volumeLevel > VOL_MIN) { volumeLevel--; changed = true; settingsMarkDirty(); }
      if (currentScreen == SCREEN_SENSOR_DIST && sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; settingsMarkDirty(); }
      if (currentScreen == SCREEN_SENSOR_TIME && sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_TIME_HOUR: decrementCurrentHour();   changed = true; break;
    case EDIT_TIME_MIN:  decrementCurrentMinute(); changed = true; break;

    case EDIT_ALARM_HOUR: decrementAlarmHour(alarmDayCursor);   changed = true; settingsMarkDirty(); break;
    case EDIT_ALARM_MIN:  decrementAlarmMinute(alarmDayCursor); changed = true; settingsMarkDirty(); break;

    case EDIT_SENSOR_DIST:
      if (sensorDistanceHalfFt > SENSOR_DIST_MIN_HALF_FT) { decSensorDist(); changed = true; settingsMarkDirty(); }
      break;

    case EDIT_SENSOR_TIME:
      if (sensorTimeHalfMin > SENSOR_TIME_MIN_HALF_MIN) { decSensorTime(); changed = true; settingsMarkDirty(); }
      break;

    default: break;
  }

  if (changed) { markActivity(); needsRedraw = true; }
}

static void readButtons() {
  unsigned long now = millis();

  // MODE
  bool modeState = digitalRead(PIN_MODE);

  if (modeState == LOW && lastModeState == HIGH) {
    markActivity();
    modePressStart = now;
  }

  if (modeState == HIGH && lastModeState == LOW) {
    unsigned long pressDuration = now - modePressStart;
    if (pressDuration >= LONG_PRESS_MS) handleModeLongPress();
    else if (pressDuration > (unsigned long)debounceMs) handleModeShortPress();
  }
  lastModeState = modeState;

  // UP
  bool upState = digitalRead(PIN_VOL_UP);

  if (upState == LOW && lastUpState == HIGH) {
    markActivity();
    if (now - lastUpPressTime > (unsigned long)debounceMs) {
      upPressStart     = now;
      upLastRepeatTime = now;
      upRepeating      = false;

      handleUpShortPress();
      lastUpPressTime  = now;
    }
  }

  if (upState == LOW) {
    if ((now - upPressStart) >= REPEAT_START_MS) {
      if (!upRepeating || (now - upLastRepeatTime) >= REPEAT_INTERVAL_MS) {
        handleUpRepeat();
        upLastRepeatTime = now;
        upRepeating      = true;
      }
    }
  }

  if (upState == HIGH && lastUpState == LOW) upRepeating = false;
  lastUpState = upState;

  // DOWN
  bool downState = digitalRead(PIN_VOL_DOWN);

  if (downState == LOW && lastDownState == HIGH) {
    markActivity();
    if (now - lastDownPressTime > (unsigned long)debounceMs) {
      downPressStart     = now;
      downLastRepeatTime = now;
      downRepeating      = false;

      handleDownShortPress();
      lastDownPressTime  = now;
    }
  }

  if (downState == LOW) {
    if ((now - downPressStart) >= REPEAT_START_MS) {
      if (!downRepeating || (now - downLastRepeatTime) >= REPEAT_INTERVAL_MS) {
        handleDownRepeat();
        downLastRepeatTime = now;
        downRepeating      = true;
      }
    }
  }

  if (downState == HIGH && lastDownState == LOW) downRepeating = false;
  lastDownState = downState;
}

// ====================== SETUP ======================
void setup() {
  Serial.begin(115200);
  delay(300);

  printWakeReason();
  printPinRtcInfo("MODE",    PIN_MODE);
  printPinRtcInfo("UP",      PIN_VOL_UP);
  printPinRtcInfo("DOWN",    PIN_VOL_DOWN);
  printPinRtcInfo("RTC_INT", PIN_RTC_INT);

  lastActivityMs = millis();

#if USE_AUDIO_MUTE_PIN
  pinMode(PIN_AUDIO_MUTE, OUTPUT);
  audioMute(true);
#endif

  pinMode(PIN_VOL_UP,   INPUT_PULLUP);
  pinMode(PIN_VOL_DOWN, INPUT_PULLUP);
  pinMode(PIN_MODE,     INPUT_PULLUP);
  pinMode(PIN_RTC_INT,  INPUT_PULLUP);

  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);

  u8g2.begin();
  u8g2.setPowerSave(0);

  settingsApplyDefaults();
  settingsLoad();

  scanI2C();

  i2sOk = installI2S();
  Serial.println(i2sOk ? "I2S OK" : "I2S FAIL");
  ensureAudioHw(false);

  melodyTotalSec = computeMelodyTotalDuration();
  Serial.print("Melody total length (sec): ");
  Serial.println(melodyTotalSec, 3);

  melodyTimeSec      = 0.0;
  oscPhase           = 0.0f;
  lastFlashToggleMs  = millis();

  lastAlarmTriggerKey = -1;

  activeSession = SESSION_NONE;
  sessionWaitingAck = false;
  sessionSoundOn = false;
  sessionSeq = 0;
  testStatus = TEST_STATUS_NONE;
  testStatusSetMs = 0;

  everHadPresenceThisSession = false;
  lastBeaconPresentThisSession = false;

  WiFi.mode(WIFI_STA);
  delay(50);
  Serial.print("Cube WiFi.macAddress() = ");
  Serial.println(WiFi.macAddress());

  espNowOk = setupEspNow();
  Serial.println(espNowOk ? "ESP-NOW OK" : "ESP-NOW FAIL");

  updateTimeFromRTC();
  alarmDayCursor = currentDayIndex;

  Serial.println("Settings persistence: NVS enabled");

  if (wokeFromRtcInt) {
    Serial.println("RTC wake detected -> clearing AF, disabling AIE briefly, starting alarm session");
    rtcSetAlarmInterruptEnabled(false);
    rtcClearAlarmFlag();
    startAlarmSessionScheduled();
  }

  rtcProgramNextAlarm(true);

  needsRedraw = true;
}

// ====================== MAIN LOOP ======================
void loop() {
  updateTimeFromRTC();

  processRxEvents();

  updateScheduledAlarmTrigger();
  updateSession();

  updateFlashState();
  readButtons();

  settingsCommitIfDue();

  if (!sessionActive()) rtcProgramNextAlarm(false);

  if (!sessionActive() && (millis() - lastActivityMs) > INACTIVITY_SLEEP_MS) {
    goToDeepSleep();
  }

  if (currentScreen == SCREEN_TEST) {
    if (testStatus != TEST_STATUS_NONE &&
        (uint32_t)(millis() - testStatusSetMs) > TEST_STATUS_SHOW_MS) {
      testStatus = TEST_STATUS_NONE;
      needsRedraw = true;
    }
  }

  if (needsRedraw) {
    updateDisplay();
    needsRedraw = false;
  }

  ensureAudioHw(audioShouldRun());

  if (!audioShouldRun()) {
    delay(10);
    return;
  }

  if (!i2sInstalled) return;

  const int FRAMES = 256;
  int16_t samples[FRAMES * 2];

  float volumeScale = volumeLevel / 10.0f;
  if (volumeScale < 0.0f) volumeScale = 0.0f;

  for (int i = 0; i < FRAMES; i++) {
    float s = getMelodySample();
    melodyTimeSec += 1.0 / (double)SAMPLE_RATE;

    int16_t sample16 = (int16_t)(s * MAX_AMPL * volumeScale);
    samples[2 * i]     = sample16;
    samples[2 * i + 1] = sample16;
  }

  size_t bytesWritten;
  i2s_write(I2S_PORT, (const char*)samples, sizeof(samples), &bytesWritten, portMAX_DELAY);
}